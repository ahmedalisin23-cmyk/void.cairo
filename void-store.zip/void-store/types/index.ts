export interface ProductVariant {
  color: string;
  colorHex: string;
  sizes: {
    S: number;
    M: number;
    L: number;
    XL: number;
    XXL: number;
  };
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  comparePrice?: number;
  images: string[];
  category: string;
  variants: ProductVariant[];
  featured: boolean;
  newArrival: boolean;
  tags: string[];
  createdAt: Date | string;
  updatedAt: Date | string;
}

export interface CartItem {
  product: Product;
  color: string;
  size: string;
  quantity: number;
}

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  customerEmail?: string;
  items: CartItem[];
  totalAmount: number;
  status: "pending" | "confirmed" | "processing" | "shipped" | "delivered" | "cancelled";
  createdAt: Date | string;
  updatedAt: Date | string;
  notes?: string;
}

export type SizeType = "S" | "M" | "L" | "XL" | "XXL";
export const SIZES: SizeType[] = ["S", "M", "L", "XL", "XXL"];
