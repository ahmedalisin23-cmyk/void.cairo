# VOID Cairo — E-Commerce Store

Dark luxury streetwear e-commerce built with Next.js 16, Firebase, and Three.js.

---

## Stack

- **Frontend**: Next.js 16 (App Router) + TypeScript + Tailwind CSS v4
- **3D**: React Three Fiber + Three.js (particle rings + floating logo)
- **Backend**: Firebase Firestore + Firebase Auth + Firebase Storage
- **State**: Zustand (cart, persisted)
- **Animations**: Framer Motion
- **Deploy**: Cloudflare Pages (or Vercel)

---

## Setup

### 1. Clone & Install

```bash
git clone <repo>
cd void-store
npm install
```

### 2. Firebase Project

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Create a new project called `void-cairo`
3. Enable:
   - **Authentication** → Email/Password
   - **Firestore Database** → Start in production mode
   - **Storage** → Start in production mode
4. Add a web app and copy the config

### 3. Environment Variables

Create `.env.local`:

```env
NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id
```

### 4. Create Admin User

In Firebase Console → Authentication → Add user:
- Email: `admin@voidcairo.com`
- Password: your secure password

### 5. Firestore Rules

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /products/{id} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    match /orders/{id} {
      allow create: if true;
      allow read, update: if request.auth != null;
    }
  }
}
```

### 6. Storage Rules

```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /products/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
```

---

## Development

```bash
npm run dev
# → http://localhost:3000
```

---

## Deploy to Cloudflare Pages

```bash
# Install Cloudflare adapter
npm install @cloudflare/next-on-pages

# Build
npx @cloudflare/next-on-pages

# Deploy
npx wrangler pages deploy .vercel/output/static --project-name void-cairo
```

Or connect GitHub repo to Cloudflare Pages with:
- **Build command**: `npx @cloudflare/next-on-pages`
- **Build output**: `.vercel/output/static`
- **Add all env variables** in Cloudflare Pages settings

---

## Deploy to Vercel (Alternative — easier)

```bash
npm install -g vercel
vercel --prod
```
Add env variables in Vercel dashboard.

---

## Pages

| Route | Description |
|-------|-------------|
| `/` | Homepage with 3D logo + particles |
| `/products` | Product listing with filters |
| `/products/[id]` | Product detail + add to cart |
| `/checkout` | Checkout form → saves to Firestore |
| `/admin/login` | Admin login (Firebase Auth) |
| `/admin/dashboard` | Full admin: products, orders, analytics |
| `/admin/products/add` | Add new product with image upload |

---

## Admin Features

- Add / Edit / Delete products
- Upload multiple product images to Firebase Storage
- Manage inventory per color + size (S/M/L/XL/XXL)
- View all orders with customer info
- Update order status (pending → confirmed → shipped → delivered)
- Export orders to Excel (.xlsx)

---

## Brand Assets

- Logo: `public/images/void-logo.png`
- Colors: Black `#000`, Dark `#080808`, Silver `#c0c0c0`, Chrome `#e8e8e8`
- Font: Bebas Neue (display) + Inter (body)
- Social: @voidcairo (Instagram + TikTok)

---

## Seed Demo Products

After Firebase setup, go to:
```
https://your-domain.com/admin/seed
```
Login with your admin account → click **RUN SEED** → 8 demo products will be added to Firestore.

---

## Project Structure

```
void-store/
├── app/
│   ├── page.tsx                    # Homepage (3D logo + featured + brand story)
│   ├── products/
│   │   ├── page.tsx                # Product listing (Firestore)
│   │   └── [id]/page.tsx           # Product detail + add to cart
│   ├── cart/page.tsx               # Cart page
│   ├── checkout/page.tsx           # Checkout → Firestore + Google Sheets
│   ├── not-found.tsx               # 404
│   ├── sitemap.ts                  # Auto sitemap
│   ├── manifest.ts                 # PWA manifest
│   └── admin/
│       ├── login/page.tsx          # Firebase Auth login
│       ├── dashboard/page.tsx      # Stats + products + orders
│       ├── products/
│       │   ├── add/page.tsx        # Add product + image upload
│       │   └── edit/page.tsx       # Edit product + inventory
│       └── seed/page.tsx           # One-click DB seed
├── components/
│   ├── 3d/VoidLogo3D.tsx           # Three.js logo + particle rings
│   ├── admin/AdminLayout.tsx       # Responsive admin sidebar
│   ├── cart/CartDrawer.tsx         # Slide-in cart
│   ├── layout/
│   │   ├── Navbar.tsx              # Nav + search (⌘K) + cart badge
│   │   └── Footer.tsx              # Links + social + contact
│   ├── product/ProductCard.tsx     # Product card component
│   └── ui/
│       ├── SearchModal.tsx         # Live search modal
│       ├── ProductSkeleton.tsx     # Loading skeleton
│       ├── ErrorState.tsx          # Error fallback
│       └── InstagramIcon.tsx       # SVG icon
├── lib/
│   ├── firebase.ts                 # Firebase init
│   ├── products.ts                 # Firestore product CRUD
│   ├── orders.ts                   # Firestore order CRUD
│   ├── sheets.ts                   # Google Sheets webhook sync
│   └── storage.ts                  # Firebase Storage upload
├── store/cart.ts                   # Zustand cart (persisted)
├── hooks/useAuth.ts                # Auth guard hook
└── types/index.ts                  # TypeScript types
```
