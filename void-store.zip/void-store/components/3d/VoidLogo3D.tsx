"use client";
import { useRef, useMemo, Suspense } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Environment } from "@react-three/drei";
import * as THREE from "three";
import Image from "next/image";

function Particles() {
  const count = 350;
  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 30;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 30;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 20;
    }
    return pos;
  }, []);

  const ref = useRef<THREE.Points>(null!);
  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * 0.012;
      ref.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.005) * 0.05;
    }
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial color={0x888888} size={0.05} transparent opacity={0.4} sizeAttenuation />
    </points>
  );
}

function MetallicRing({ radius, speed, tilt, color }: { radius: number; speed: number; tilt: number; color: number }) {
  const ref = useRef<THREE.Mesh>(null!);
  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.z = state.clock.elapsedTime * speed;
      ref.current.rotation.x = tilt + Math.sin(state.clock.elapsedTime * 0.3) * 0.05;
    }
  });

  const geo = useMemo(() => new THREE.TorusGeometry(radius, 0.006, 16, 120), [radius]);
  const mat = useMemo(() => new THREE.MeshStandardMaterial({
    color: new THREE.Color(color),
    metalness: 1,
    roughness: 0.08,
    envMapIntensity: 2.5,
  }), [color]);

  return <mesh ref={ref} geometry={geo} material={mat} />;
}

function Scene() {
  return (
    <>
      <ambientLight intensity={0.1} />
      <spotLight position={[12, 12, 8]} angle={0.2} penumbra={1} intensity={4} color={0xffffff} />
      <spotLight position={[-12, -8, 4]} angle={0.2} penumbra={1} intensity={1.5} color={0x8888bb} />
      <pointLight position={[0, 0, 6]} intensity={2} color={0xcccccc} />
      <Environment preset="city" />
      <Particles />
      <Float speed={0.8} rotationIntensity={0.06} floatIntensity={0.3}>
        <MetallicRing radius={4.5} speed={0.18} tilt={0.25} color={0x777777} />
        <MetallicRing radius={5.5} speed={-0.13} tilt={-0.45} color={0x555555} />
        <MetallicRing radius={3.5} speed={0.28} tilt={1.1} color={0x999999} />
        <MetallicRing radius={6.2} speed={-0.08} tilt={0.7} color={0x444444} />
      </Float>
    </>
  );
}

export function ParticleCanvas({ height = "60vh" }: { height?: string }) {
  return (
    <div style={{ width: "100%", height }} className="absolute inset-0 pointer-events-none">
      <Canvas camera={{ position: [0, 0, 12], fov: 45 }} dpr={[1, 2]} gl={{ antialias: true, alpha: true }}>
        <Suspense fallback={null}>
          <Scene />
        </Suspense>
      </Canvas>
    </div>
  );
}

export default function VoidLogo3D({ height = "60vh" }: { height?: string }) {
  return (
    <div style={{ width: "100%", height }} className="relative flex items-center justify-center">
      {/* 3D particle background */}
      <ParticleCanvas height={height} />

      {/* Real logo centered on top */}
      <div className="relative z-10 flex flex-col items-center justify-center gap-8">
        <div className="relative">
          {/* Chrome glow behind logo */}
          <div className="absolute inset-0 blur-[60px] bg-white/10 scale-150 rounded-full" />
          <Image
            src="/images/void-logo.png"
            alt="VOID"
            width={500}
            height={200}
            className="relative w-[280px] sm:w-[380px] md:w-[480px] h-auto object-contain
              drop-shadow-[0_0_40px_rgba(255,255,255,0.15)]
              hover:drop-shadow-[0_0_60px_rgba(255,255,255,0.25)]
              transition-all duration-700
              animate-float"
            priority
          />
        </div>
      </div>
    </div>
  );
}
