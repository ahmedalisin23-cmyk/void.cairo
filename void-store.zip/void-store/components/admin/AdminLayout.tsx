"use client";
import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { TrendingUp, Package, ShoppingBag, LogOut, Menu, X } from "lucide-react";

type Tab = "overview" | "products" | "orders";

export default function AdminLayout({
  children,
  activeTab,
  onTabChange,
}: {
  children: React.ReactNode;
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}) {
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = async () => {
    await signOut(auth);
    router.push("/admin/login");
  };

  const tabs: { key: Tab; label: string; Icon: typeof TrendingUp }[] = [
    { key: "overview", label: "OVERVIEW", Icon: TrendingUp },
    { key: "products", label: "PRODUCTS", Icon: Package },
    { key: "orders", label: "ORDERS", Icon: ShoppingBag },
  ];

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-6 border-b border-void-border">
        <Image src="/images/void-logo.png" alt="VOID" width={100} height={40} className="h-8 w-auto object-contain mb-1" />
        <p className="text-[10px] tracking-[0.3em] text-void-muted mt-2">ADMIN PANEL</p>
      </div>
      <nav className="flex-1 p-4 space-y-1">
        {tabs.map(({ key, label, Icon }) => (
          <button
            key={key}
            onClick={() => { onTabChange(key); setSidebarOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 text-left text-xs tracking-[0.15em] transition-all duration-200 border-l-2 ${
              activeTab === key
                ? "text-void-chrome bg-void-silver/10 border-void-silver"
                : "text-void-muted hover:text-void-chrome hover:bg-void-border/30 border-transparent"
            }`}
          >
            <Icon size={14} />
            {label}
          </button>
        ))}
      </nav>
      <div className="p-4 border-t border-void-border space-y-1">
        <Link href="/" className="w-full flex items-center gap-3 px-4 py-2.5 text-xs tracking-[0.15em] text-void-muted hover:text-void-chrome transition-colors">
          ← VIEW STORE
        </Link>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-4 py-2.5 text-xs tracking-[0.15em] text-void-muted hover:text-red-400 transition-colors"
        >
          <LogOut size={13} /> LOGOUT
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-black flex">
      {/* Desktop Sidebar */}
      <div className="hidden md:flex fixed left-0 top-0 bottom-0 w-60 bg-void-dark border-r border-void-border z-40 flex-col">
        <SidebarContent />
      </div>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          <div className="fixed inset-0 bg-black/70" onClick={() => setSidebarOpen(false)} />
          <div className="relative w-64 bg-void-dark border-r border-void-border flex flex-col z-10">
            <button
              onClick={() => setSidebarOpen(false)}
              className="absolute top-4 right-4 p-1 text-void-muted hover:text-void-chrome"
            >
              <X size={18} />
            </button>
            <SidebarContent />
          </div>
        </div>
      )}

      {/* Mobile top bar */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-14 bg-void-dark border-b border-void-border flex items-center px-4 gap-4 z-40">
        <button onClick={() => setSidebarOpen(true)} className="p-1.5 text-void-muted hover:text-void-chrome">
          <Menu size={18} />
        </button>
        <Image src="/images/void-logo.png" alt="VOID" width={80} height={32} className="h-7 w-auto object-contain" />
        <span className="text-[10px] tracking-[0.3em] text-void-muted ml-1">ADMIN</span>
      </div>

      {/* Main content */}
      <div className="flex-1 md:ml-60 pt-14 md:pt-0">
        <div className="p-5 sm:p-8">
          {children}
        </div>
      </div>
    </div>
  );
}
