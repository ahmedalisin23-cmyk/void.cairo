import Link from "next/link";
import Image from "next/image";
import { Mail, MapPin } from "lucide-react";
import InstagramIcon from "@/components/ui/InstagramIcon";

export default function Footer() {
  return (
    <footer className="border-t border-void-border bg-void-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-2">
            <Image src="/images/void-logo.png" alt="VOID" width={140} height={56} className="h-11 w-auto object-contain mb-5 opacity-90" />
            <p className="text-void-muted text-sm leading-relaxed max-w-xs">
              Dark luxury streetwear from Cairo. Mystery over noise. Feeling over product.
            </p>
            <div className="flex gap-3 mt-6">
              <a href="https://instagram.com/voidcairo" target="_blank" rel="noopener noreferrer"
                className="p-2.5 border border-void-border hover:border-void-accent transition-colors group">
                <InstagramIcon size={15} className="text-void-muted group-hover:text-void-chrome transition-colors" />
              </a>
              <a href="https://tiktok.com/@voidcairo" target="_blank" rel="noopener noreferrer"
                className="px-3 py-2 border border-void-border hover:border-void-accent transition-colors text-void-muted hover:text-void-chrome text-[10px] font-bold tracking-widest flex items-center">
                TIKTOK
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-[10px] tracking-[0.3em] text-void-chrome mb-5 uppercase">Shop</h4>
            <ul className="space-y-3">
              {["All Products", "Tees", "Hoodies", "Accessories", "New Arrivals"].map((item) => (
                <li key={item}>
                  <Link href="/products" className="text-sm text-void-muted hover:text-void-chrome transition-colors duration-200">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[10px] tracking-[0.3em] text-void-chrome mb-5 uppercase">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-void-muted">
                <MapPin size={13} className="text-void-accent flex-shrink-0" />Cairo, Egypt
              </li>
              <li className="flex items-center gap-2 text-sm text-void-muted">
                <Mail size={13} className="text-void-accent flex-shrink-0" />hello@voidcairo.com
              </li>
              <li className="flex items-center gap-2 text-sm text-void-muted">
                <InstagramIcon size={13} className="text-void-accent flex-shrink-0" />@voidcairo
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-void-border mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[10px] text-void-muted tracking-[0.2em]">© {new Date().getFullYear()} VOID CAIRO. ALL RIGHTS RESERVED.</p>
          <p className="text-[10px] text-void-muted tracking-[0.2em]">BUILT IN CAIRO · WORN EVERYWHERE</p>
        </div>
      </div>
    </footer>
  );
}
