"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { ShoppingBag, Menu, X, Search } from "lucide-react";
import { useCart } from "@/store/cart";
import CartDrawer from "@/components/cart/CartDrawer";
import SearchModal from "@/components/ui/SearchModal";
import { motion, AnimatePresence } from "framer-motion";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { count, toggleCart } = useCart();

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  // Keyboard shortcut: CMD+K / CTRL+K
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const navLinks = [
    { href: "/products", label: "SHOP" },
    { href: "/products?category=tees", label: "TEES" },
    { href: "/products?category=hoodies", label: "HOODIES" },
    { href: "/products?category=accessories", label: "ACCESSORIES" },
  ];

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "bg-black/92 backdrop-blur-xl border-b border-void-border" : "bg-transparent"
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">

            {/* Logo */}
            <Link href="/" className="group flex items-center">
              <Image
                src="/images/void-logo.png"
                alt="VOID"
                width={110}
                height={44}
                className="h-9 w-auto object-contain transition-all duration-300 group-hover:brightness-125 group-hover:drop-shadow-[0_0_16px_rgba(255,255,255,0.18)]"
                priority
              />
            </Link>

            {/* Desktop links */}
            <div className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link key={link.href} href={link.href}
                  className="text-[11px] tracking-[0.25em] text-void-muted hover:text-void-chrome transition-colors duration-200 relative group">
                  {link.label}
                  <span className="absolute -bottom-0.5 left-0 w-0 h-px bg-void-silver group-hover:w-full transition-all duration-300" />
                </Link>
              ))}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-1">
              <button
                onClick={() => setSearchOpen(true)}
                className="p-2.5 text-void-muted hover:text-void-chrome transition-colors duration-200 group relative"
                title="Search (⌘K)"
              >
                <Search size={17} />
              </button>
              <button
                onClick={toggleCart}
                className="relative p-2.5 text-void-muted hover:text-void-chrome transition-colors duration-200"
              >
                <ShoppingBag size={17} />
                <AnimatePresence>
                  {count() > 0 && (
                    <motion.span
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      exit={{ scale: 0 }}
                      className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-void-silver text-black text-[9px] font-bold rounded-full flex items-center justify-center"
                    >
                      {count()}
                    </motion.span>
                  )}
                </AnimatePresence>
              </button>
              <button
                className="md:hidden p-2.5 text-void-muted hover:text-void-chrome transition-colors duration-200"
                onClick={() => setMobileOpen(!mobileOpen)}
              >
                {mobileOpen ? <X size={17} /> : <Menu size={17} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        <AnimatePresence>
          {mobileOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-black/96 backdrop-blur-xl border-b border-void-border overflow-hidden"
            >
              <div className="px-6 py-4 flex flex-col">
                {navLinks.map((link) => (
                  <Link key={link.href} href={link.href} onClick={() => setMobileOpen(false)}
                    className="text-sm tracking-[0.2em] text-void-muted hover:text-void-chrome py-3.5 border-b border-void-border/40 transition-colors">
                    {link.label}
                  </Link>
                ))}
                <button
                  onClick={() => { setMobileOpen(false); setSearchOpen(true); }}
                  className="text-sm tracking-[0.2em] text-void-muted hover:text-void-chrome py-3.5 border-b border-void-border/40 transition-colors text-left flex items-center gap-2"
                >
                  <Search size={14} /> SEARCH
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <CartDrawer />
      <SearchModal isOpen={searchOpen} onClose={() => setSearchOpen(false)} />
    </>
  );
}
