"use client";
import { useCart } from "@/store/cart";
import { motion, AnimatePresence } from "framer-motion";
import { X, Trash2, Plus, Minus, ShoppingBag } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

export default function CartDrawer() {
  const { isOpen, toggleCart, items, removeItem, updateQuantity, total, clearCart } = useCart();

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={toggleCart}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed right-0 top-0 h-full w-full sm:w-[420px] bg-void-dark border-l border-void-border z-50 flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-void-border">
              <div className="flex items-center gap-3">
                <ShoppingBag size={18} className="text-void-chrome" />
                <span className="text-sm tracking-[0.15em] font-medium">YOUR CART</span>
                <span className="text-xs text-void-muted">({items.length})</span>
              </div>
              <button
                onClick={toggleCart}
                className="p-1 text-void-muted hover:text-void-chrome transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
                  <div className="w-16 h-16 border border-void-border flex items-center justify-center">
                    <ShoppingBag size={24} className="text-void-muted" />
                  </div>
                  <p className="text-void-muted text-sm tracking-wider">THE VOID IS EMPTY</p>
                  <button onClick={toggleCart} className="text-xs text-void-chrome tracking-[0.2em] underline underline-offset-4">
                    CONTINUE SHOPPING
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {items.map((item, idx) => (
                    <div key={`${item.product.id}-${item.color}-${item.size}-${idx}`}
                      className="flex gap-4 py-4 border-b border-void-border/50">
                      <div className="w-20 h-24 bg-void-card border border-void-border relative overflow-hidden flex-shrink-0">
                        {item.product.images[0] ? (
                          <Image src={item.product.images[0]} alt={item.product.name} fill className="object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-xs text-void-muted font-display tracking-widest">
                            VOID
                          </div>
                        )}
                      </div>
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <h4 className="text-sm font-medium tracking-wider">{item.product.name}</h4>
                          <p className="text-xs text-void-muted mt-1">
                            {item.color} · {item.size}
                          </p>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 border border-void-border">
                            <button
                              onClick={() => updateQuantity(item.product.id, item.color, item.size, item.quantity - 1)}
                              className="p-1.5 hover:bg-void-border transition-colors"
                            >
                              <Minus size={12} />
                            </button>
                            <span className="text-sm w-6 text-center">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.product.id, item.color, item.size, item.quantity + 1)}
                              className="p-1.5 hover:bg-void-border transition-colors"
                            >
                              <Plus size={12} />
                            </button>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="text-sm font-medium">
                              EGP {(item.product.price * item.quantity).toLocaleString()}
                            </span>
                            <button
                              onClick={() => removeItem(item.product.id, item.color, item.size)}
                              className="text-void-muted hover:text-red-400 transition-colors"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {items.length > 0 && (
              <div className="border-t border-void-border px-6 py-6 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs tracking-[0.15em] text-void-muted">SUBTOTAL</span>
                  <span className="text-lg font-medium">EGP {total().toLocaleString()}</span>
                </div>
                <Link href="/checkout" onClick={toggleCart}>
                  <button className="w-full btn-chrome py-4 text-sm tracking-[0.2em] font-bold uppercase">
                    CHECKOUT
                  </button>
                </Link>
                <button
                  onClick={clearCart}
                  className="w-full text-xs text-void-muted hover:text-void-chrome transition-colors tracking-wider"
                >
                  CLEAR CART
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
