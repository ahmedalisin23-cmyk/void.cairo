"use client";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { Product } from "@/types";
import { ShoppingBag } from "lucide-react";

export default function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Link href={`/products/${product.id}`} className="group block product-card">
        {/* Image */}
        <div className="relative overflow-hidden bg-void-card border border-void-border aspect-[3/4]">
          {product.images[0] ? (
            <Image
              src={product.images[0]}
              alt={product.name}
              fill
              className="object-cover product-card-img"
              sizes="(max-width: 768px) 50vw, 25vw"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <span className="text-5xl font-display tracking-[0.3em] text-chrome opacity-20">VOID</span>
            </div>
          )}

          {/* Tags */}
          <div className="absolute top-3 left-3 flex gap-2">
            {product.newArrival && (
              <span className="px-2 py-0.5 bg-void-silver text-black text-[10px] font-bold tracking-widest">
                NEW
              </span>
            )}
            {product.comparePrice && product.comparePrice > product.price && (
              <span className="px-2 py-0.5 bg-red-900/80 text-red-300 text-[10px] font-bold tracking-widest">
                SALE
              </span>
            )}
          </div>

          {/* Quick add overlay */}
          <div className="absolute inset-x-0 bottom-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300 bg-black/90 backdrop-blur-sm p-3 flex items-center justify-center gap-2">
            <ShoppingBag size={14} className="text-void-chrome" />
            <span className="text-xs tracking-[0.2em] text-void-chrome">QUICK VIEW</span>
          </div>
        </div>

        {/* Info */}
        <div className="mt-3 px-1">
          <h3 className="text-sm tracking-wider font-medium group-hover:text-void-chrome transition-colors">
            {product.name}
          </h3>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-sm text-void-chrome">
              EGP {product.price.toLocaleString()}
            </span>
            {product.comparePrice && product.comparePrice > product.price && (
              <span className="text-xs text-void-muted line-through">
                EGP {product.comparePrice.toLocaleString()}
              </span>
            )}
          </div>

          {/* Color swatches */}
          {product.variants && product.variants.length > 0 && (
            <div className="flex gap-1.5 mt-2">
              {product.variants.map((v) => (
                <div
                  key={v.color}
                  className="w-3 h-3 rounded-full border border-void-border"
                  style={{ backgroundColor: v.colorHex }}
                  title={v.color}
                />
              ))}
            </div>
          )}
        </div>
      </Link>
    </motion.div>
  );
}
