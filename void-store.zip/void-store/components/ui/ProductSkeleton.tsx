export default function ProductSkeleton() {
  return (
    <div className="animate-pulse">
      <div className="aspect-[3/4] bg-void-card border border-void-border" />
      <div className="mt-3 space-y-2">
        <div className="h-3 bg-void-border rounded w-3/4" />
        <div className="h-3 bg-void-border rounded w-1/3" />
      </div>
    </div>
  );
}

export function ProductSkeletonGrid({ count = 8 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
      {Array(count).fill(null).map((_, i) => (
        <ProductSkeleton key={i} />
      ))}
    </div>
  );
}
