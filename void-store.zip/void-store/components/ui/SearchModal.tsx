"use client";
import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { getProducts } from "@/lib/products";
import type { Product } from "@/types";

export default function SearchModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Product[]>([]);
  const [all, setAll] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setLoading(true);
      getProducts().then((p) => { setAll(p); setLoading(false); });
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      setQuery("");
      setResults([]);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!query.trim()) { setResults([]); return; }
    const q = query.toLowerCase();
    setResults(
      all.filter((p) =>
        p.name.toLowerCase().includes(q) ||
        p.description?.toLowerCase().includes(q) ||
        p.category?.toLowerCase().includes(q) ||
        p.tags?.some((t) => t.toLowerCase().includes(q))
      ).slice(0, 6)
    );
  }, [query, all]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
          />
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-0 left-0 right-0 z-50 bg-void-dark border-b border-void-border shadow-2xl"
          >
            {/* Search input */}
            <div className="max-w-3xl mx-auto px-4 py-5 flex items-center gap-4">
              <Search size={18} className="text-void-muted flex-shrink-0" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="SEARCH VOID..."
                className="flex-1 bg-transparent text-void-chrome placeholder:text-void-muted text-sm tracking-widest outline-none"
              />
              <button onClick={onClose} className="p-1 text-void-muted hover:text-void-chrome transition-colors">
                <X size={18} />
              </button>
            </div>

            {/* Results */}
            <AnimatePresence>
              {(query.trim().length > 0) && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="max-w-3xl mx-auto px-4 pb-5 overflow-hidden"
                >
                  {loading && (
                    <p className="text-xs tracking-[0.3em] text-void-muted py-4 text-center animate-pulse">SEARCHING...</p>
                  )}
                  {!loading && results.length === 0 && (
                    <p className="text-xs tracking-[0.3em] text-void-muted py-4 text-center">
                      NO RESULTS FOR &quot;{query.toUpperCase()}&quot;
                    </p>
                  )}
                  {!loading && results.length > 0 && (
                    <div className="space-y-1">
                      {results.map((product) => (
                        <Link
                          key={product.id}
                          href={`/products/${product.id}`}
                          onClick={onClose}
                          className="flex items-center gap-4 p-3 hover:bg-void-border/30 transition-colors group"
                        >
                          <div className="w-12 h-14 bg-void-card border border-void-border flex items-center justify-center flex-shrink-0 overflow-hidden">
                            {product.images?.[0] ? (
                              <Image src={product.images[0]} alt="" width={48} height={56} className="object-cover w-full h-full" />
                            ) : (
                              <Image src="/images/void-logo.png" alt="" width={32} height={12} className="opacity-20 w-4/5 h-auto object-contain" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs tracking-wider group-hover:text-void-chrome transition-colors truncate">{product.name}</p>
                            <p className="text-[10px] text-void-muted mt-0.5">{product.category.toUpperCase()}</p>
                          </div>
                          <span className="text-sm text-void-chrome flex-shrink-0">EGP {product.price.toLocaleString()}</span>
                        </Link>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
