import Image from "next/image";
import { RefreshCw } from "lucide-react";

export default function ErrorState({
  message = "SOMETHING WENT WRONG",
  onRetry,
}: {
  message?: string;
  onRetry?: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-24 px-4 text-center">
      <Image
        src="/images/void-logo.png"
        alt="VOID"
        width={100}
        height={40}
        className="w-24 h-auto object-contain opacity-10 mb-6"
      />
      <p className="text-xs tracking-[0.3em] text-void-muted mb-4">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="btn-primary px-6 py-2.5 text-xs tracking-[0.2em] flex items-center gap-2"
        >
          <RefreshCw size={13} />
          TRY AGAIN
        </button>
      )}
    </div>
  );
}
