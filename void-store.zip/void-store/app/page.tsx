"use client";
import dynamic from "next/dynamic";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import InstagramIcon from "@/components/ui/InstagramIcon";

const VoidLogo3D = dynamic(() => import("@/components/3d/VoidLogo3D"), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center" style={{ height: "60vh" }}>
      <Image src="/images/void-logo.png" alt="VOID" width={400} height={160} className="w-[320px] h-auto object-contain opacity-20 animate-pulse" priority />
    </div>
  ),
});

import { useEffect, useState } from "react";
import { getFeaturedProducts } from "@/lib/products";
import type { Product } from "@/types";

const FALLBACK_PRODUCTS = [
  { id: "1", name: "VOID OVERSIZED TEE — ONYX", price: 899, newArrival: true, images: [], variants: [], category: "tees", description: "", featured: true, tags: [], createdAt: "", updatedAt: "" },
  { id: "2", name: "VOID HEAVY TEE — GREY VOID", price: 899, newArrival: false, images: [], variants: [], category: "tees", description: "", featured: true, tags: [], createdAt: "", updatedAt: "" },
  { id: "3", name: "VOID HOODIE — ONYX", price: 1499, newArrival: true, images: [], variants: [], category: "hoodies", description: "", featured: true, tags: [], createdAt: "", updatedAt: "" },
  { id: "4", name: "VOID LOGO CAP — CHROME", price: 499, newArrival: false, images: [], variants: [], category: "accessories", description: "", featured: true, tags: [], createdAt: "", updatedAt: "" },
] as Product[];

function HeroSection() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[70vw] h-[50vh] bg-white/[0.025] blur-[140px] rounded-full" />
      </div>

      <div className="w-full max-w-4xl mx-auto">
        <VoidLogo3D height="58vh" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.8 }}
        className="text-center px-4 -mt-4 z-10"
      >
        <p className="text-[10px] tracking-[0.5em] text-void-muted uppercase mb-8">
          Mystery over noise · Feeling over product
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link href="/products">
            <button className="btn-chrome px-12 py-4 text-xs tracking-[0.3em] font-bold uppercase">
              SHOP NOW
            </button>
          </Link>
          <Link href="/products?new=true">
            <button className="btn-primary px-12 py-4 text-xs tracking-[0.25em] uppercase">
              NEW ARRIVALS
            </button>
          </Link>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-[9px] tracking-[0.4em] text-void-muted">SCROLL</span>
        <div className="w-px h-10 bg-gradient-to-b from-void-muted to-transparent" />
      </motion.div>
    </section>
  );
}

function AnnouncementBanner() {
  const text = "FREE SHIPPING OVER EGP 1,500 · NEW DROP EVERY FRIDAY · LIMITED QUANTITIES · CAIRO MADE · WORN EVERYWHERE · ";
  return (
    <div className="bg-void-dark border-y border-void-border overflow-hidden py-3">
      <div className="flex whitespace-nowrap" style={{ animation: "marquee 22s linear infinite" }}>
        {Array(4).fill(text).map((t, i) => (
          <span key={i} className="text-[10px] tracking-[0.3em] text-void-muted px-0 inline-block">{t}</span>
        ))}
      </div>
    </div>
  );
}

function FeaturedSection() {
  const [products, setProducts] = useState<Product[]>(FALLBACK_PRODUCTS);

  useEffect(() => {
    getFeaturedProducts()
      .then((data) => { if (data.length > 0) setProducts(data.slice(0, 4)); })
      .catch(() => {/* use fallback */});
  }, []);

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="flex items-end justify-between mb-12"
      >
        <div>
          <p className="text-[10px] tracking-[0.5em] text-void-muted mb-2">CURATED</p>
          <h2 className="text-5xl sm:text-6xl font-display tracking-[0.15em] text-chrome" style={{ fontFamily: "'Bebas Neue', sans-serif" }}>FEATURED</h2>
        </div>
        <Link href="/products" className="flex items-center gap-2 text-xs tracking-[0.2em] text-void-muted hover:text-void-chrome transition-colors group">
          VIEW ALL <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
        </Link>
      </motion.div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {products.map((product, i) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
          >
            <Link href={`/products/${product.id}`} className="group block">
              <div className="relative overflow-hidden bg-void-card border border-void-border aspect-[3/4] flex items-center justify-center transition-all duration-300 group-hover:border-void-accent">
                <Image
                  src="/images/void-logo.png"
                  alt={product.name}
                  width={120}
                  height={48}
                  className="w-2/3 h-auto object-contain opacity-10 group-hover:opacity-20 transition-opacity duration-500 group-hover:scale-105 transition-transform"
                />
                {product.newArrival && (
                  <span className="absolute top-3 left-3 px-2 py-0.5 bg-void-silver text-black text-[10px] font-bold tracking-widest">
                    NEW
                  </span>
                )}
                <div className="absolute inset-x-0 bottom-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300 bg-black/90 p-3 text-center">
                  <span className="text-[11px] tracking-[0.2em] text-void-chrome">QUICK VIEW</span>
                </div>
              </div>
              <div className="mt-3">
                <h3 className="text-xs tracking-wider font-medium group-hover:text-void-chrome transition-colors line-clamp-1">
                  {product.name}
                </h3>
                <p className="text-sm text-void-chrome mt-1 font-medium">EGP {product.price.toLocaleString()}</p>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

function BrandStory() {
  return (
    <section className="py-28 border-y border-void-border relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/[0.015] to-transparent pointer-events-none" />
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <p className="text-[10px] tracking-[0.6em] text-void-muted mb-8">ABOUT THE VOID</p>
          <h2 className="text-5xl sm:text-7xl text-chrome mb-10 leading-none" style={{ fontFamily: "'Bebas Neue', sans-serif", letterSpacing: "0.15em" }}>
            BORN FROM<br />DARKNESS
          </h2>
          <p className="text-sm text-void-muted leading-relaxed max-w-2xl mx-auto mb-4">
            VOID was born in Cairo from a desire to create something that didn&apos;t yet exist —
            dark luxury streetwear for those who refuse to be ordinary. Every piece is designed
            with intention: heavy fabrics, unexpected placements, zero noise.
          </p>
          <p className="text-sm text-void-muted leading-relaxed max-w-2xl mx-auto">
            We don&apos;t sell products. We sell a feeling. The feeling of standing apart,
            of carrying mystery, of wearing the void itself.
          </p>
          <div className="mt-14 flex items-center justify-center gap-12">
            {["CAIRO MADE", "LIMITED DROPS", "HEAVY QUALITY"].map((stat) => (
              <div key={stat}>
                <p className="text-[10px] tracking-[0.3em] text-void-muted">{stat}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function SocialSection() {
  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-12"
      >
        <p className="text-[10px] tracking-[0.5em] text-void-muted mb-3">FOLLOW US</p>
        <h2 className="text-5xl sm:text-6xl text-chrome mb-5" style={{ fontFamily: "'Bebas Neue', sans-serif", letterSpacing: "0.2em" }}>@VOIDCAIRO</h2>
        <a
          href="https://instagram.com/voidcairo"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 text-xs tracking-[0.25em] text-void-muted hover:text-void-chrome transition-colors"
        >
          <InstagramIcon size={14} />
          FOLLOW ON INSTAGRAM
        </a>
      </motion.div>

      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
        {Array(6).fill(null).map((_, i) => (
          <motion.a
            key={i}
            href="https://instagram.com/voidcairo"
            target="_blank"
            rel="noopener noreferrer"
            initial={{ opacity: 0, scale: 0.92 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.07 }}
            className="aspect-square bg-void-card border border-void-border flex items-center justify-center group hover:border-void-accent transition-colors overflow-hidden"
          >
            <Image
              src="/images/void-logo.png"
              alt=""
              width={60}
              height={24}
              className="w-3/5 h-auto object-contain opacity-10 group-hover:opacity-25 transition-opacity duration-500 group-hover:scale-110 transition-transform"
            />
          </motion.a>
        ))}
      </div>
    </section>
  );
}

function NewsletterSection() {
  return (
    <section className="py-20 border-t border-void-border">
      <div className="max-w-2xl mx-auto px-4 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <p className="text-[10px] tracking-[0.5em] text-void-muted mb-3">STAY IN THE VOID</p>
          <h2 className="text-4xl text-chrome mb-8" style={{ fontFamily: "'Bebas Neue', sans-serif", letterSpacing: "0.2em" }}>
            GET EARLY ACCESS
          </h2>
          <div className="flex gap-0 max-w-md mx-auto">
            <input
              type="email"
              placeholder="YOUR EMAIL"
              className="flex-1 bg-transparent border border-void-border border-r-0 px-5 py-3.5 text-xs tracking-[0.15em] text-void-chrome placeholder:text-void-border focus:outline-none focus:border-void-silver transition-colors"
            />
            <button className="btn-chrome px-6 py-3.5 text-[10px] tracking-[0.2em] font-bold whitespace-nowrap">
              JOIN
            </button>
          </div>
          <p className="text-[10px] text-void-muted tracking-wider mt-4">
            DROP ALERTS · EARLY ACCESS · EXCLUSIVE CONTENT
          </p>
        </motion.div>
      </div>
    </section>
  );
}

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <AnnouncementBanner />
      <FeaturedSection />
      <BrandStory />
      <SocialSection />
      <NewsletterSection />
    </>
  );
}
