import { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    { url: "https://voidcairo.com", lastModified: new Date(), changeFrequency: "weekly", priority: 1 },
    { url: "https://voidcairo.com/products", lastModified: new Date(), changeFrequency: "daily", priority: 0.9 },
    { url: "https://voidcairo.com/cart", lastModified: new Date(), changeFrequency: "never", priority: 0.3 },
    { url: "https://voidcairo.com/checkout", lastModified: new Date(), changeFrequency: "never", priority: 0.3 },
  ];
}
