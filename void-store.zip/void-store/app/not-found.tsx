"use client";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 text-center">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <Image
          src="/images/void-logo.png"
          alt="VOID"
          width={200}
          height={80}
          className="w-40 h-auto object-contain mx-auto mb-10 opacity-20"
        />
        <p className="text-[10px] tracking-[0.6em] text-void-muted mb-4">ERROR 404</p>
        <h1
          className="text-chrome mb-6 leading-none"
          style={{ fontSize: "clamp(4rem, 15vw, 10rem)", fontFamily: "'Bebas Neue', sans-serif", letterSpacing: "0.1em" }}
        >
          VOID
        </h1>
        <p className="text-void-muted text-sm tracking-widest mb-10">
          THIS PAGE DOESN&apos;T EXIST — LIKE THE VOID ITSELF
        </p>
        <Link href="/">
          <button className="btn-chrome px-12 py-4 text-xs tracking-[0.3em] font-bold">
            RETURN TO HOME
          </button>
        </Link>
      </motion.div>
    </div>
  );
}
