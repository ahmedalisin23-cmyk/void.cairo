"use client";
export const dynamic = "force-dynamic";
import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { auth } from "@/lib/firebase";
import { onAuthStateChanged } from "firebase/auth";
import { getOrders, updateOrderStatus } from "@/lib/orders";
import { getProducts, deleteProduct } from "@/lib/products";
import { motion } from "framer-motion";
import { Package, ShoppingBag, TrendingUp, DollarSign, Plus, Trash2, Edit, Download, RefreshCw, ExternalLink } from "lucide-react";
import Link from "next/link";
import AdminLayout from "@/components/admin/AdminLayout";
import * as XLSX from "xlsx";
import type { Order, Product } from "@/types";

type Tab = "overview" | "products" | "orders";

const STATUS_COLORS: Record<string, string> = {
  pending:    "text-amber-400 bg-amber-400/10 border-amber-400/20",
  confirmed:  "text-blue-400 bg-blue-400/10 border-blue-400/20",
  processing: "text-purple-400 bg-purple-400/10 border-purple-400/20",
  shipped:    "text-cyan-400 bg-cyan-400/10 border-cyan-400/20",
  delivered:  "text-green-400 bg-green-400/10 border-green-400/20",
  cancelled:  "text-red-400 bg-red-400/10 border-red-400/20",
};

export default function AdminDashboard() {
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("overview");
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [o, p] = await Promise.all([getOrders(), getProducts()]);
      setOrders(o);
      setProducts(p);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      if (!user) router.push("/admin/login");
      else fetchData();
    });
    return () => unsub();
  }, [fetchData, router]);

  const handleDeleteProduct = async (id: string) => {
    if (!confirm("DELETE THIS PRODUCT? THIS CANNOT BE UNDONE.")) return;
    await deleteProduct(id);
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const handleStatusChange = async (orderId: string, status: Order["status"]) => {
    await updateOrderStatus(orderId, status);
    setOrders((prev) => prev.map((o) => o.id === orderId ? { ...o, status } : o));
  };

  const exportToExcel = () => {
    const data = orders.map((o) => ({
      "Order ID":   o.id.slice(0, 8).toUpperCase(),
      "Date":       new Date(o.createdAt as string).toLocaleDateString("en-EG"),
      "Customer":   o.customerName,
      "Phone":      o.customerPhone,
      "Email":      o.customerEmail || "—",
      "Address":    o.customerAddress,
      "Items":      o.items.map((i) => `${i.product.name} (${i.color}/${i.size} ×${i.quantity})`).join(" | "),
      "Total EGP":  o.totalAmount,
      "Status":     o.status.toUpperCase(),
      "Notes":      o.notes || "—",
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    ws["!cols"] = [8,10,15,13,18,22,40,10,10,15].map((w) => ({ wch: w }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "VOID Orders");
    XLSX.writeFile(wb, `void-orders-${new Date().toISOString().slice(0,10)}.xlsx`);
  };

  // Stats
  const totalRevenue = orders.filter((o) => o.status !== "cancelled").reduce((s, o) => s + o.totalAmount, 0);
  const pendingCount = orders.filter((o) => o.status === "pending").length;
  const deliveredCount = orders.filter((o) => o.status === "delivered").length;

  if (loading) {
    return (
      <AdminLayout activeTab={tab} onTabChange={setTab}>
        <div className="flex items-center justify-center h-64">
          <div className="text-xs tracking-[0.4em] text-void-muted animate-pulse">LOADING VOID DATA...</div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout activeTab={tab} onTabChange={setTab}>
      {/* ── OVERVIEW ── */}
      {tab === "overview" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
          <div>
            <p className="text-[10px] tracking-[0.4em] text-void-muted mb-1">VOID CAIRO</p>
            <h1 className="text-3xl sm:text-4xl text-chrome" style={{ fontFamily: "'Bebas Neue',sans-serif", letterSpacing: "0.2em" }}>DASHBOARD</h1>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {[
              { label: "TOTAL REVENUE", value: `EGP ${totalRevenue.toLocaleString()}`, Icon: DollarSign, color: "text-green-400" },
              { label: "TOTAL ORDERS", value: orders.length, Icon: ShoppingBag, color: "text-blue-400" },
              { label: "PENDING", value: pendingCount, Icon: Package, color: "text-amber-400" },
              { label: "DELIVERED", value: deliveredCount, Icon: TrendingUp, color: "text-purple-400" },
            ].map(({ label, value, Icon, color }) => (
              <div key={label} className="card-void p-4 sm:p-6">
                <Icon size={16} className={`${color} mb-3`} />
                <p className="text-xl sm:text-2xl font-bold text-void-chrome">{value}</p>
                <p className="text-[9px] tracking-[0.2em] text-void-muted mt-1">{label}</p>
              </div>
            ))}
          </div>

          {/* Recent orders */}
          <div className="card-void p-5 sm:p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xs tracking-[0.25em] text-void-chrome">RECENT ORDERS</h2>
              <button onClick={() => setTab("orders")} className="text-[10px] tracking-wider text-void-muted hover:text-void-chrome transition-colors">
                VIEW ALL →
              </button>
            </div>
            <div className="space-y-3">
              {orders.length === 0 && (
                <p className="text-xs tracking-wider text-void-muted text-center py-6">NO ORDERS YET</p>
              )}
              {orders.slice(0, 6).map((order) => (
                <div key={order.id} className="flex items-center justify-between py-3 border-b border-void-border/40 last:border-0">
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{order.customerName}</p>
                    <p className="text-xs text-void-muted mt-0.5 truncate">{order.customerPhone}</p>
                  </div>
                  <div className="text-right flex-shrink-0 ml-4">
                    <p className="text-sm text-void-chrome font-medium">EGP {order.totalAmount.toLocaleString()}</p>
                    <span className={`inline-block text-[9px] tracking-wider px-2 py-0.5 rounded border mt-1 ${STATUS_COLORS[order.status]}`}>
                      {order.status.toUpperCase()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick actions */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Link href="/admin/products/add">
              <button className="btn-chrome w-full py-3.5 text-xs tracking-[0.2em] font-bold flex items-center justify-center gap-2">
                <Plus size={13} /> ADD PRODUCT
              </button>
            </Link>
            <button onClick={exportToExcel} className="btn-primary w-full py-3.5 text-xs tracking-[0.2em] flex items-center justify-center gap-2">
              <Download size={13} /> EXPORT ORDERS
            </button>
            <Link href="/admin/seed">
              <button className="btn-primary w-full py-3.5 text-xs tracking-[0.2em] flex items-center justify-center gap-2">
                <Package size={13} /> SEED DB
              </button>
            </Link>
            <Link href="/" target="_blank">
              <button className="btn-primary w-full py-3.5 text-xs tracking-[0.2em] flex items-center justify-center gap-2">
                <ExternalLink size={13} /> VIEW STORE
              </button>
            </Link>
          </div>
        </motion.div>
      )}

      {/* ── PRODUCTS ── */}
      {tab === "products" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[10px] tracking-[0.4em] text-void-muted mb-1">MANAGE</p>
              <h1 className="text-3xl text-chrome" style={{ fontFamily: "'Bebas Neue',sans-serif", letterSpacing: "0.2em" }}>PRODUCTS</h1>
              <p className="text-xs text-void-muted mt-1">{products.length} ITEMS</p>
            </div>
            <Link href="/admin/products/add">
              <button className="btn-chrome px-5 sm:px-6 py-2.5 text-xs tracking-[0.2em] font-bold flex items-center gap-2">
                <Plus size={13} /> ADD
              </button>
            </Link>
          </div>

          <div className="space-y-3">
            {products.length === 0 && (
              <div className="card-void p-12 text-center">
                <p className="text-void-muted text-sm tracking-wider mb-4">NO PRODUCTS YET</p>
                <Link href="/admin/products/add">
                  <button className="btn-primary px-6 py-2.5 text-xs tracking-wider">ADD FIRST PRODUCT</button>
                </Link>
              </div>
            )}
            {products.map((product) => (
              <div key={product.id} className="card-void p-4 flex items-center gap-4">
                <div className="w-14 h-16 sm:w-16 sm:h-18 bg-void-border/20 border border-void-border flex items-center justify-center flex-shrink-0 overflow-hidden" style={{ height: "4.5rem" }}>
                  {product.images?.[0] ? (
                    <Image src={product.images[0]} alt={product.name} width={64} height={72} className="object-cover w-full h-full" />
                  ) : (
                    <Image src="/images/void-logo.png" alt="" width={40} height={16} className="opacity-15 w-4/5 h-auto object-contain" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{product.name}</p>
                  <p className="text-xs text-void-muted mt-0.5">{product.category.toUpperCase()} · EGP {product.price.toLocaleString()}</p>
                  <div className="flex gap-2 mt-1.5">
                    {product.newArrival && <span className="text-[9px] tracking-wider text-void-silver bg-void-silver/10 px-1.5 py-0.5 border border-void-silver/20">NEW</span>}
                    {product.featured && <span className="text-[9px] tracking-wider text-blue-400 bg-blue-400/10 px-1.5 py-0.5 border border-blue-400/20">FEATURED</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Link href={`/admin/products/edit?id=${product.id}`}>
                    <button className="p-2 text-void-muted hover:text-void-chrome border border-void-border hover:border-void-accent transition-all">
                      <Edit size={13} />
                    </button>
                  </Link>
                  <button
                    onClick={() => handleDeleteProduct(product.id)}
                    className="p-2 text-void-muted hover:text-red-400 border border-void-border hover:border-red-900/50 transition-all"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* ── ORDERS ── */}
      {tab === "orders" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-[10px] tracking-[0.4em] text-void-muted mb-1">MANAGE</p>
              <h1 className="text-3xl text-chrome" style={{ fontFamily: "'Bebas Neue',sans-serif", letterSpacing: "0.2em" }}>ORDERS</h1>
              <p className="text-xs text-void-muted mt-1">{orders.length} TOTAL · {pendingCount} PENDING</p>
            </div>
            <div className="flex gap-2">
              <button onClick={fetchData} className="btn-primary px-4 py-2.5 text-xs tracking-[0.15em] flex items-center gap-1.5">
                <RefreshCw size={12} /> REFRESH
              </button>
              <button onClick={exportToExcel} className="btn-chrome px-4 sm:px-5 py-2.5 text-xs tracking-[0.15em] font-bold flex items-center gap-1.5">
                <Download size={13} /> XLSX
              </button>
            </div>
          </div>

          <div className="space-y-4">
            {orders.length === 0 && (
              <div className="card-void p-12 text-center">
                <p className="text-void-muted text-sm tracking-wider">NO ORDERS YET</p>
              </div>
            )}
            {orders.map((order) => (
              <div key={order.id} className="card-void p-5 sm:p-6">
                <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <h3 className="text-sm font-medium">{order.customerName}</h3>
                      <span className={`text-[9px] tracking-wider px-2 py-0.5 rounded border ${STATUS_COLORS[order.status]}`}>
                        {order.status.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-xs text-void-muted">{order.customerPhone}</p>
                    <p className="text-xs text-void-muted mt-0.5 max-w-xs truncate">{order.customerAddress}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-semibold text-void-chrome">EGP {order.totalAmount.toLocaleString()}</p>
                    <p className="text-[10px] text-void-muted mt-0.5">
                      {order.createdAt ? new Date(order.createdAt as string).toLocaleDateString("en-EG") : "—"}
                    </p>
                  </div>
                </div>

                {/* Items */}
                <div className="bg-void-border/10 border border-void-border/40 p-3 mb-4 space-y-1">
                  {order.items.map((item, i) => (
                    <p key={i} className="text-xs text-void-muted">
                      <span className="text-void-chrome">{item.product.name}</span>
                      {" · "}{item.color} / {item.size} · ×{item.quantity}
                      {" · "}EGP {(item.product.price * item.quantity).toLocaleString()}
                    </p>
                  ))}
                </div>

                {order.notes && (
                  <p className="text-xs text-void-muted italic mb-3">Note: {order.notes}</p>
                )}

                <div className="flex flex-wrap items-center gap-3">
                  <span className="text-[10px] tracking-wider text-void-muted">STATUS:</span>
                  <select
                    value={order.status}
                    onChange={(e) => handleStatusChange(order.id, e.target.value as Order["status"])}
                    className="bg-void-card border border-void-border text-xs text-void-chrome px-3 py-1.5 outline-none cursor-pointer hover:border-void-accent transition-colors"
                  >
                    {["pending","confirmed","processing","shipped","delivered","cancelled"].map((s) => (
                      <option key={s} value={s} className="bg-black">{s.toUpperCase()}</option>
                    ))}
                  </select>
                  <a
                    href={`https://wa.me/${order.customerPhone.replace(/[^0-9]/g, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[10px] tracking-wider text-green-400 hover:text-green-300 transition-colors border border-green-900/40 px-3 py-1.5 hover:border-green-700/40"
                  >
                    📱 WHATSAPP
                  </a>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </AdminLayout>
  );
}
