"use client";
export const dynamic = "force-dynamic";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { addProduct } from "@/lib/products";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, Play, CheckCircle2, XCircle, Loader2 } from "lucide-react";

const SEED_PRODUCTS = [
  {
    name: "VOID OVERSIZED TEE — ONYX",
    description: "300gsm heavyweight cotton. Oversized silhouette. Dark grey 3D foam VOID logo on left chest. Pre-washed. Built to last, designed to disturb.",
    price: 899, comparePrice: undefined, category: "tees", featured: true, newArrival: true,
    tags: ["oversized", "tee", "black", "heavyweight", "premium"], images: [],
    variants: [
      { color: "Onyx Black",   colorHex: "#000000", sizes: { S:8,  M:12, L:15, XL:10, XXL:5  } },
      { color: "Washed Black", colorHex: "#111111", sizes: { S:5,  M:8,  L:10, XL:6,  XXL:3  } },
      { color: "Charcoal",     colorHex: "#2a2a2a", sizes: { S:3,  M:6,  L:8,  XL:5,  XXL:2  } },
    ],
  },
  {
    name: "VOID HEAVY TEE — GREY VOID",
    description: "Same heavyweight formula. Grey canvas for the 3D foam logo to breathe. Drop silhouette. Unisex fit.",
    price: 899, comparePrice: 1099, category: "tees", featured: true, newArrival: false,
    tags: ["oversized", "tee", "grey", "heavyweight"], images: [],
    variants: [
      { color: "Ash Grey",  colorHex: "#888888", sizes: { S:6, M:10, L:12, XL:8, XXL:4 } },
      { color: "Dark Grey", colorHex: "#444444", sizes: { S:4, M:7,  L:9,  XL:5, XXL:2 } },
    ],
  },
  {
    name: "VOID HOODIE — ONYX",
    description: "500gsm fleece. Double-layered hood. Kangaroo pocket. VOID chest logo in matte 3D rubber. The winter essential.",
    price: 1499, comparePrice: undefined, category: "hoodies", featured: true, newArrival: true,
    tags: ["hoodie", "black", "fleece", "winter", "premium"], images: [],
    variants: [
      { color: "Onyx Black",   colorHex: "#000000", sizes: { S:5, M:8, L:10, XL:7, XXL:3 } },
      { color: "Washed Black", colorHex: "#1a1a1a", sizes: { S:3, M:5, L:7,  XL:4, XXL:2 } },
    ],
  },
  {
    name: "VOID HOODIE — ASH",
    description: "Same 500gsm formula in Ash Grey. Cold weather uniform. Oversized but structured.",
    price: 1499, comparePrice: undefined, category: "hoodies", featured: false, newArrival: false,
    tags: ["hoodie", "grey", "fleece", "winter"], images: [],
    variants: [
      { color: "Ash Grey", colorHex: "#888888", sizes: { S:4, M:7, L:9, XL:6, XXL:3 } },
    ],
  },
  {
    name: "VOID LOGO CAP — CHROME",
    description: "6-panel structured cap. Chrome VOID embroidery front. Adjustable buckle strap. One size fits most.",
    price: 499, comparePrice: undefined, category: "accessories", featured: false, newArrival: false,
    tags: ["cap", "hat", "chrome", "accessories"], images: [],
    variants: [
      { color: "Black/Chrome", colorHex: "#000000", sizes: { S:20, M:20, L:20, XL:20, XXL:20 } },
    ],
  },
  {
    name: "VOID CARGO PANTS — ONYX",
    description: "Heavyweight twill cargo pants. 8 pockets. VOID tab on left cargo pocket. Relaxed tapered fit.",
    price: 1899, comparePrice: undefined, category: "pants", featured: false, newArrival: true,
    tags: ["cargo", "pants", "black", "premium", "limited"], images: [],
    variants: [
      { color: "Onyx Black",   colorHex: "#000000", sizes: { S:5, M:8, L:8, XL:5, XXL:2 } },
      { color: "Washed Black", colorHex: "#222222", sizes: { S:3, M:5, L:5, XL:3, XXL:1 } },
    ],
  },
  {
    name: "VOID LONG SLEEVE — BLACK VOID",
    description: "Midweight 220gsm long sleeve. Clean base. VOID logo on left chest, subtle back print. Layering essential.",
    price: 999, comparePrice: undefined, category: "tees", featured: false, newArrival: false,
    tags: ["longsleeve", "tee", "black", "layering"], images: [],
    variants: [
      { color: "Black",       colorHex: "#000000", sizes: { S:8, M:12, L:14, XL:9, XXL:4 } },
      { color: "Faded Black", colorHex: "#1c1c1c", sizes: { S:4, M:6,  L:8,  XL:5, XXL:2 } },
    ],
  },
  {
    name: "VOID BEANIE — ONYX",
    description: "100% merino wool. Ribbed construction. Subtle VOID patch on fold. Unisex.",
    price: 349, comparePrice: undefined, category: "accessories", featured: false, newArrival: false,
    tags: ["beanie", "wool", "winter", "accessories"], images: [],
    variants: [
      { color: "Onyx Black", colorHex: "#000000", sizes: { S:20, M:20, L:20, XL:20, XXL:20 } },
      { color: "Dark Grey",  colorHex: "#555555", sizes: { S:15, M:15, L:15, XL:15, XXL:15 } },
    ],
  },
];

type SeedStatus = "idle" | "running" | "done" | "error";
type Log = { name: string; status: "ok" | "fail" };

export default function SeedPage() {
  const { loading } = useAuth(true);
  const router = useRouter();
  const [status, setStatus] = useState<SeedStatus>("idle");
  const [logs, setLogs] = useState<Log[]>([]);
  const [current, setCurrent] = useState("");

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <p className="text-xs tracking-[0.3em] text-void-muted animate-pulse">CHECKING AUTH...</p>
      </div>
    );
  }

  const runSeed = async () => {
    setStatus("running");
    setLogs([]);
    const newLogs: Log[] = [];

    for (const product of SEED_PRODUCTS) {
      setCurrent(product.name);
      try {
        await addProduct(product as Parameters<typeof addProduct>[0]);
        newLogs.push({ name: product.name, status: "ok" });
      } catch {
        newLogs.push({ name: product.name, status: "fail" });
      }
      setLogs([...newLogs]);
    }

    setCurrent("");
    setStatus(newLogs.some((l) => l.status === "fail") ? "error" : "done");
  };

  return (
    <div className="min-h-screen bg-black p-8">
      <div className="max-w-2xl mx-auto">
        <Link
          href="/admin/dashboard"
          className="flex items-center gap-2 text-void-muted hover:text-void-chrome text-xs tracking-wider mb-8 transition-colors"
        >
          <ArrowLeft size={14} /> BACK TO DASHBOARD
        </Link>

        <div className="mb-8">
          <Image src="/images/void-logo.png" alt="VOID" width={100} height={40} className="h-8 w-auto object-contain mb-5 opacity-80" />
          <p className="text-[10px] tracking-[0.5em] text-void-muted mb-2">DATABASE UTILITY</p>
          <h1 className="text-4xl text-chrome" style={{ fontFamily: "'Bebas Neue',sans-serif", letterSpacing: "0.2em" }}>
            SEED PRODUCTS
          </h1>
          <p className="text-sm text-void-muted mt-3 leading-relaxed">
            Adds {SEED_PRODUCTS.length} demo products to Firestore. Run once after Firebase setup.
          </p>
        </div>

        {/* Product list */}
        <div className="card-void p-5 mb-6 space-y-1">
          <p className="text-[10px] tracking-[0.3em] text-void-muted mb-4">PRODUCTS TO SEED</p>
          {SEED_PRODUCTS.map((p, i) => {
            const log = logs.find((l) => l.name === p.name);
            const isRunning = status === "running" && current === p.name;
            return (
              <div key={i} className="flex items-center justify-between py-2.5 border-b border-void-border/30 last:border-0">
                <div>
                  <p className="text-xs tracking-wider">{p.name}</p>
                  <p className="text-[10px] text-void-muted mt-0.5">
                    {p.category.toUpperCase()} · EGP {p.price.toLocaleString()} · {p.variants.length} COLOR{p.variants.length > 1 ? "S" : ""}
                  </p>
                </div>
                <div className="flex-shrink-0 ml-4 w-5 flex items-center justify-center">
                  {isRunning && <Loader2 size={13} className="text-void-muted animate-spin" />}
                  {log?.status === "ok"   && <CheckCircle2 size={13} className="text-green-400" />}
                  {log?.status === "fail" && <XCircle size={13} className="text-red-400" />}
                </div>
              </div>
            );
          })}
        </div>

        {/* Actions */}
        {status === "idle" && (
          <button
            onClick={runSeed}
            className="btn-chrome w-full py-4 text-sm tracking-[0.25em] font-bold flex items-center justify-center gap-2"
          >
            <Play size={14} /> RUN SEED — {SEED_PRODUCTS.length} PRODUCTS
          </button>
        )}

        {status === "running" && (
          <div className="card-void p-5 flex items-center gap-3">
            <Loader2 size={16} className="text-void-muted animate-spin flex-shrink-0" />
            <p className="text-xs tracking-wider text-void-muted truncate">ADDING: {current}</p>
          </div>
        )}

        {status === "done" && (
          <div className="space-y-3">
            <div className="border border-green-900/40 bg-green-900/10 p-4 flex items-center gap-3">
              <CheckCircle2 size={15} className="text-green-400 flex-shrink-0" />
              <p className="text-xs tracking-wider text-green-400">
                ALL {SEED_PRODUCTS.length} PRODUCTS ADDED SUCCESSFULLY
              </p>
            </div>
            <button
              onClick={() => router.push("/admin/dashboard")}
              className="btn-chrome w-full py-4 text-xs tracking-[0.25em] font-bold"
            >
              GO TO DASHBOARD
            </button>
          </div>
        )}

        {status === "error" && (
          <div className="space-y-3">
            <div className="border border-red-900/40 bg-red-900/10 p-4 flex items-center gap-3">
              <XCircle size={15} className="text-red-400 flex-shrink-0" />
              <p className="text-xs tracking-wider text-red-400">
                SOME PRODUCTS FAILED — CHECK FIREBASE CONFIG
              </p>
            </div>
            <button onClick={runSeed} className="btn-primary w-full py-3.5 text-xs tracking-[0.2em]">
              RETRY FAILED
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
