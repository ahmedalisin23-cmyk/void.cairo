"use client";
export const dynamic = "force-dynamic";
import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Image from "next/image";
import { getProduct, updateProduct } from "@/lib/products";
import { ref as storageRef, uploadBytes, getDownloadURL } from "firebase/storage";
import { storage } from "@/lib/firebase";
import { ArrowLeft, Upload, X, Save } from "lucide-react";
import Link from "next/link";
import toast from "react-hot-toast";
import type { Product } from "@/types";
import { Suspense } from "react";

const SIZES = ["S", "M", "L", "XL", "XXL"] as const;

function EditForm() {
  const router = useRouter();
  const params = useSearchParams();
  const productId = params.get("id");
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [uploadingImgs, setUploadingImgs] = useState(false);
  const [product, setProduct] = useState<Product | null>(null);
  const [images, setImages] = useState<string[]>([]);
  const [variants, setVariants] = useState<Product["variants"]>([]);
  const [form, setForm] = useState({
    name: "", description: "", price: "", comparePrice: "",
    category: "tees", featured: false, newArrival: false, tags: "",
  });

  useEffect(() => {
    if (!productId) { router.push("/admin/dashboard"); return; }
    getProduct(productId).then((p) => {
      if (!p) { toast.error("PRODUCT NOT FOUND"); router.push("/admin/dashboard"); return; }
      setProduct(p);
      setImages(p.images || []);
      setVariants(p.variants || []);
      setForm({
        name: p.name,
        description: p.description,
        price: String(p.price),
        comparePrice: p.comparePrice ? String(p.comparePrice) : "",
        category: p.category,
        featured: p.featured,
        newArrival: p.newArrival,
        tags: (p.tags || []).join(", "),
      });
      setFetching(false);
    });
  }, [productId, router]);

  const handleImageUpload = async (files: FileList) => {
    setUploadingImgs(true);
    const urls: string[] = [];
    for (const file of Array.from(files)) {
      const path = `products/${Date.now()}-${file.name}`;
      const sRef = storageRef(storage, path);
      await uploadBytes(sRef, file);
      const url = await getDownloadURL(sRef);
      urls.push(url);
    }
    setImages([...images, ...urls]);
    setUploadingImgs(false);
    toast.success(`${urls.length} IMAGE(S) UPLOADED`);
  };

  const updateVariantSize = (vIdx: number, size: string, val: number) => {
    const v = [...variants];
    (v[vIdx].sizes as Record<string, number>)[size] = val;
    setVariants(v);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productId) return;
    setLoading(true);
    try {
      await updateProduct(productId, {
        name: form.name,
        description: form.description,
        price: Number(form.price),
        comparePrice: form.comparePrice ? Number(form.comparePrice) : undefined,
        category: form.category,
        featured: form.featured,
        newArrival: form.newArrival,
        tags: form.tags.split(",").map(t => t.trim()).filter(Boolean),
        images,
        variants,
      });
      toast.success("PRODUCT UPDATED");
      router.push("/admin/dashboard");
    } catch {
      toast.error("UPDATE FAILED");
    } finally {
      setLoading(false);
    }
  };

  if (fetching) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <p className="text-xs tracking-[0.3em] text-void-muted animate-pulse">LOADING...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black p-8">
      <div className="max-w-3xl mx-auto">
        <Link href="/admin/dashboard" className="flex items-center gap-2 text-void-muted hover:text-void-chrome text-xs tracking-wider mb-8 transition-colors">
          <ArrowLeft size={14} /> BACK TO DASHBOARD
        </Link>
        <h1 className="text-3xl mb-2 text-chrome" style={{ fontFamily: "'Bebas Neue', sans-serif", letterSpacing: "0.2em" }}>
          EDIT PRODUCT
        </h1>
        <p className="text-xs text-void-muted tracking-wider mb-8">{form.name}</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Info */}
          <div className="card-void p-6 space-y-4">
            <h2 className="text-xs tracking-[0.2em] text-void-chrome">BASIC INFORMATION</h2>
            {[
              { key: "name", label: "PRODUCT NAME *", type: "text" },
              { key: "price", label: "PRICE (EGP) *", type: "number" },
              { key: "comparePrice", label: "COMPARE PRICE (EGP)", type: "number" },
            ].map(({ key, label, type }) => (
              <div key={key}>
                <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">{label}</label>
                <input
                  type={type}
                  value={form[key as keyof typeof form] as string}
                  onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                  className="w-full bg-transparent border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none transition-colors"
                />
              </div>
            ))}
            <div>
              <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">DESCRIPTION</label>
              <textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={3}
                className="w-full bg-transparent border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none transition-colors resize-none"
              />
            </div>
            <div>
              <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">CATEGORY</label>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full bg-void-card border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none"
              >
                {["tees", "hoodies", "pants", "accessories", "outerwear"].map(c => (
                  <option key={c} value={c} className="bg-black">{c.toUpperCase()}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">TAGS (COMMA SEPARATED)</label>
              <input
                type="text"
                value={form.tags}
                onChange={(e) => setForm({ ...form, tags: e.target.value })}
                className="w-full bg-transparent border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none transition-colors"
              />
            </div>
            <div className="flex gap-6">
              {[["featured", "FEATURED"], ["newArrival", "NEW ARRIVAL"]].map(([key, label]) => (
                <label key={key} className="flex items-center gap-3 cursor-pointer group">
                  <div
                    onClick={() => setForm({ ...form, [key]: !form[key as keyof typeof form] })}
                    className={`w-4 h-4 border-2 transition-colors flex items-center justify-center ${
                      form[key as keyof typeof form]
                        ? "bg-void-silver border-void-silver"
                        : "border-void-border group-hover:border-void-accent"
                    }`}
                  >
                    {form[key as keyof typeof form] && <span className="text-black text-[10px] font-bold">✓</span>}
                  </div>
                  <span className="text-xs tracking-[0.15em] text-void-muted group-hover:text-void-chrome transition-colors">{label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Images */}
          <div className="card-void p-6 space-y-4">
            <h2 className="text-xs tracking-[0.2em] text-void-chrome">PRODUCT IMAGES</h2>
            {images.length > 0 && (
              <div className="grid grid-cols-4 gap-2 mb-3">
                {images.map((url, i) => (
                  <div key={i} className="relative aspect-square border border-void-border overflow-hidden group">
                    <Image src={url} alt="" fill className="object-cover" />
                    <button
                      type="button"
                      onClick={() => setImages(images.filter((_, idx) => idx !== i))}
                      className="absolute top-1 right-1 p-1 bg-black/80 text-red-400 hover:text-red-300 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X size={12} />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <label className="flex flex-col items-center justify-center border border-dashed border-void-border p-6 cursor-pointer hover:border-void-accent transition-colors group">
              <Upload size={20} className="text-void-muted group-hover:text-void-chrome transition-colors mb-2" />
              <span className="text-xs tracking-wider text-void-muted group-hover:text-void-chrome transition-colors">
                {uploadingImgs ? "UPLOADING..." : "ADD MORE IMAGES"}
              </span>
              <input
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={(e) => e.target.files && handleImageUpload(e.target.files)}
              />
            </label>
          </div>

          {/* Variants / Inventory */}
          <div className="card-void p-6 space-y-4">
            <h2 className="text-xs tracking-[0.2em] text-void-chrome">COLORS & INVENTORY</h2>
            {variants.map((variant, vIdx) => (
              <div key={vIdx} className="border border-void-border p-4 space-y-4">
                <div className="flex gap-3 items-center">
                  <div
                    className="w-6 h-6 rounded-full border-2 border-void-border flex-shrink-0"
                    style={{ backgroundColor: variant.colorHex }}
                  />
                  <span className="text-sm font-medium tracking-wider">{variant.color}</span>
                </div>
                <div>
                  <label className="block text-[10px] tracking-wider text-void-muted mb-2">INVENTORY PER SIZE</label>
                  <div className="grid grid-cols-5 gap-2">
                    {SIZES.map((size) => (
                      <div key={size}>
                        <p className="text-[10px] text-void-muted text-center mb-1">{size}</p>
                        <input
                          type="number"
                          min={0}
                          value={(variant.sizes as Record<string, number>)[size] ?? 0}
                          onChange={(e) => updateVariantSize(vIdx, size, Number(e.target.value))}
                          className="w-full bg-transparent border border-void-border px-2 py-2 text-sm text-void-chrome text-center focus:border-void-silver focus:outline-none"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-chrome w-full py-4 text-sm tracking-[0.25em] font-bold uppercase flex items-center justify-center gap-2 disabled:opacity-40"
          >
            <Save size={16} />
            {loading ? "SAVING..." : "SAVE CHANGES"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default function EditProductPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-black flex items-center justify-center">
        <p className="text-xs tracking-[0.3em] text-void-muted animate-pulse">LOADING...</p>
      </div>
    }>
      <EditForm />
    </Suspense>
  );
}
