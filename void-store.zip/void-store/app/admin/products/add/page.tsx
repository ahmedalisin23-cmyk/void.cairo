"use client";
export const dynamic = "force-dynamic";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { addProduct } from "@/lib/products";
import { getStorage, ref as storageRef, uploadBytes, getDownloadURL } from "firebase/storage";
import { storage } from "@/lib/firebase";
import { Plus, X, Upload, ArrowLeft } from "lucide-react";
import Link from "next/link";
import toast from "react-hot-toast";

const SIZES = ["S", "M", "L", "XL", "XXL"] as const;

interface Variant {
  color: string;
  colorHex: string;
  sizes: { S: number; M: number; L: number; XL: number; XXL: number };
}

export default function AddProduct() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [uploadingImgs, setUploadingImgs] = useState(false);
  const [form, setForm] = useState({
    name: "", description: "", price: "", comparePrice: "",
    category: "tees", featured: false, newArrival: false, tags: "",
  });
  const [images, setImages] = useState<string[]>([]);
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [variants, setVariants] = useState<Variant[]>([
    { color: "Black", colorHex: "#000000", sizes: { S: 0, M: 0, L: 0, XL: 0, XXL: 0 } }
  ]);

  const handleImageUpload = async (files: FileList) => {
    setUploadingImgs(true);
    const urls: string[] = [];
    for (const file of Array.from(files)) {
      const path = `products/${Date.now()}-${file.name}`;
      const sRef = storageRef(storage, path);
      await uploadBytes(sRef, file);
      const url = await getDownloadURL(sRef);
      urls.push(url);
    }
    setImages([...images, ...urls]);
    setUploadingImgs(false);
    toast.success(`${urls.length} IMAGE(S) UPLOADED`);
  };

  const addVariant = () => {
    setVariants([...variants, { color: "", colorHex: "#111111", sizes: { S: 0, M: 0, L: 0, XL: 0, XXL: 0 } }]);
  };

  const updateVariant = (i: number, field: string, value: string) => {
    const v = [...variants];
    (v[i] as any)[field] = value;
    setVariants(v);
  };

  const updateVariantSize = (vIdx: number, size: string, val: number) => {
    const v = [...variants];
    (v[vIdx].sizes as Record<string, number>)[size] = val;
    setVariants(v);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.price) { toast.error("FILL REQUIRED FIELDS"); return; }
    setLoading(true);
    try {
      await addProduct({
        name: form.name,
        description: form.description,
        price: Number(form.price),
        comparePrice: form.comparePrice ? Number(form.comparePrice) : undefined,
        category: form.category,
        featured: form.featured,
        newArrival: form.newArrival,
        tags: form.tags.split(",").map(t => t.trim()).filter(Boolean),
        images,
        variants,
      });
      toast.success("PRODUCT ADDED");
      router.push("/admin/dashboard");
    } catch (err) {
      toast.error("FAILED TO ADD PRODUCT");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black p-8">
      <div className="max-w-3xl mx-auto">
        <Link href="/admin/dashboard" className="flex items-center gap-2 text-void-muted hover:text-void-chrome text-xs tracking-wider mb-8 transition-colors">
          <ArrowLeft size={14} />
          BACK TO DASHBOARD
        </Link>
        <h1 className="text-3xl font-display tracking-[0.2em] text-chrome mb-8">ADD PRODUCT</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Info */}
          <div className="card-void p-6 space-y-4">
            <h2 className="text-xs tracking-[0.2em] text-void-chrome">BASIC INFORMATION</h2>
            {[
              { key: "name", label: "PRODUCT NAME *", type: "text" },
              { key: "price", label: "PRICE (EGP) *", type: "number" },
              { key: "comparePrice", label: "COMPARE PRICE (EGP)", type: "number" },
            ].map(({ key, label, type }) => (
              <div key={key}>
                <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">{label}</label>
                <input
                  type={type}
                  value={form[key as keyof typeof form] as string}
                  onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                  className="w-full bg-transparent border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none transition-colors"
                />
              </div>
            ))}
            <div>
              <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">DESCRIPTION</label>
              <textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={3}
                className="w-full bg-transparent border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none transition-colors resize-none"
              />
            </div>
            <div>
              <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">CATEGORY</label>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full bg-void-card border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none"
              >
                {["tees", "hoodies", "pants", "accessories", "outerwear"].map(c => (
                  <option key={c} value={c} className="bg-black">{c.toUpperCase()}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">TAGS (COMMA SEPARATED)</label>
              <input
                type="text"
                value={form.tags}
                onChange={(e) => setForm({ ...form, tags: e.target.value })}
                placeholder="oversized, premium, limited"
                className="w-full bg-transparent border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none transition-colors"
              />
            </div>
            <div className="flex gap-6">
              {[["featured", "FEATURED"], ["newArrival", "NEW ARRIVAL"]].map(([key, label]) => (
                <label key={key} className="flex items-center gap-3 cursor-pointer group">
                  <div
                    onClick={() => setForm({ ...form, [key]: !form[key as keyof typeof form] })}
                    className={`w-4 h-4 border transition-colors ${form[key as keyof typeof form] ? "bg-void-silver border-void-silver" : "border-void-border group-hover:border-void-accent"}`}
                  />
                  <span className="text-xs tracking-[0.15em] text-void-muted group-hover:text-void-chrome transition-colors">{label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Images */}
          <div className="card-void p-6 space-y-4">
            <h2 className="text-xs tracking-[0.2em] text-void-chrome">PRODUCT IMAGES</h2>
            <label className="flex flex-col items-center justify-center border border-dashed border-void-border p-8 cursor-pointer hover:border-void-accent transition-colors group">
              <Upload size={24} className="text-void-muted group-hover:text-void-chrome transition-colors mb-2" />
              <span className="text-xs tracking-wider text-void-muted group-hover:text-void-chrome transition-colors">
                {uploadingImgs ? "UPLOADING..." : "CLICK TO UPLOAD IMAGES"}
              </span>
              <input
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={(e) => e.target.files && handleImageUpload(e.target.files)}
              />
            </label>
            {images.length > 0 && (
              <div className="grid grid-cols-4 gap-2">
                {images.map((url, i) => (
                  <div key={i} className="relative aspect-square border border-void-border overflow-hidden">
                    <Image src={url} alt="" fill className="object-cover" />
                    <button
                      type="button"
                      onClick={() => setImages(images.filter((_, idx) => idx !== i))}
                      className="absolute top-1 right-1 p-1 bg-black/80 text-red-400 hover:text-red-300"
                    >
                      <X size={12} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Variants */}
          <div className="card-void p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xs tracking-[0.2em] text-void-chrome">COLORS & INVENTORY</h2>
              <button type="button" onClick={addVariant} className="btn-primary px-3 py-1.5 text-[10px] tracking-wider flex items-center gap-1">
                <Plus size={12} />ADD COLOR
              </button>
            </div>

            {variants.map((variant, vIdx) => (
              <div key={vIdx} className="border border-void-border p-4 space-y-4">
                <div className="flex gap-3">
                  <div className="flex-1">
                    <label className="block text-[10px] tracking-wider text-void-muted mb-1">COLOR NAME</label>
                    <input
                      value={variant.color}
                      onChange={(e) => updateVariant(vIdx, "color", e.target.value)}
                      placeholder="Black"
                      className="w-full bg-transparent border border-void-border px-3 py-2 text-sm text-void-chrome focus:border-void-silver focus:outline-none"
                    />
                  </div>
                  <div className="w-24">
                    <label className="block text-[10px] tracking-wider text-void-muted mb-1">HEX</label>
                    <input
                      type="color"
                      value={variant.colorHex}
                      onChange={(e) => updateVariant(vIdx, "colorHex", e.target.value)}
                      className="w-full h-10 bg-transparent border border-void-border cursor-pointer"
                    />
                  </div>
                  {variants.length > 1 && (
                    <button type="button" onClick={() => setVariants(variants.filter((_, i) => i !== vIdx))} className="p-2 text-red-400 hover:text-red-300 self-end mb-0.5">
                      <X size={16} />
                    </button>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] tracking-wider text-void-muted mb-2">INVENTORY PER SIZE</label>
                  <div className="grid grid-cols-5 gap-2">
                    {SIZES.map((size) => (
                      <div key={size}>
                        <p className="text-[10px] text-void-muted text-center mb-1">{size}</p>
                        <input
                          type="number"
                          min={0}
                          value={variant.sizes[size] ?? 0}
                          onChange={(e) => updateVariantSize(vIdx, size, Number(e.target.value))}
                          className="w-full bg-transparent border border-void-border px-2 py-2 text-sm text-void-chrome text-center focus:border-void-silver focus:outline-none"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-chrome w-full py-4 text-sm tracking-[0.25em] font-bold uppercase disabled:opacity-40"
          >
            {loading ? "SAVING..." : "SAVE PRODUCT"}
          </button>
        </form>
      </div>
    </div>
  );
}
