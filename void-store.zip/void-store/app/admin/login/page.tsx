"use client";
export const dynamic = "force-dynamic";
import { useState } from "react";
import Image from "next/image";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Eye, EyeOff, Lock } from "lucide-react";

export default function AdminLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await signInWithEmailAndPassword(auth, email, password);
      router.push("/admin/dashboard");
    } catch (err: any) {
      setError("INVALID CREDENTIALS");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-black">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40vw] h-[40vh] bg-void-silver/[0.03] blur-[100px] rounded-full" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm relative z-10"
      >
        {/* Logo */}
        <div className="text-center mb-10">
          <Image
            src="/images/void-logo.png"
            alt="VOID"
            width={160}
            height={64}
            className="h-14 w-auto object-contain mx-auto mb-6 opacity-90"
          />
          <p className="text-[10px] tracking-[0.4em] text-void-muted">ADMIN ACCESS</p>
        </div>

        <form onSubmit={handleLogin} className="card-void p-8 space-y-5">
          <div className="flex items-center justify-center mb-2">
            <Lock size={16} className="text-void-muted" />
          </div>

          <div>
            <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">EMAIL</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full bg-transparent border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none transition-colors"
              placeholder="admin@voidcairo.com"
            />
          </div>

          <div>
            <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">PASSWORD</label>
            <div className="relative">
              <input
                type={showPw ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full bg-transparent border border-void-border px-4 py-3 pr-12 text-sm text-void-chrome focus:border-void-silver focus:outline-none transition-colors"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPw(!showPw)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-void-muted hover:text-void-chrome transition-colors"
              >
                {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {error && (
            <p className="text-xs text-red-400 tracking-wider text-center">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="btn-chrome w-full py-3.5 text-xs tracking-[0.25em] font-bold uppercase mt-2 disabled:opacity-40"
          >
            {loading ? "AUTHENTICATING..." : "ENTER VOID ADMIN"}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
