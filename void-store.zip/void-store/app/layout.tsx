import type { Metadata } from "next";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Toaster } from "react-hot-toast";

export const metadata: Metadata = {
  title: "VOID — Dark Luxury Streetwear | Cairo",
  description: "Mystery over noise. Feeling over product. Dark luxury streetwear from Cairo.",
  keywords: ["streetwear", "Cairo", "Egypt", "luxury", "VOID"],
  openGraph: {
    title: "VOID — Dark Luxury Streetwear",
    description: "Mystery over noise. Feeling over product.",
    siteName: "VOID Cairo",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="grain-overlay antialiased">
        <Navbar />
        <main className="min-h-screen">{children}</main>
        <Footer />
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: "#0d0d0d",
              color: "#e8e8e8",
              border: "1px solid #1a1a1a",
              borderRadius: 0,
              fontSize: "12px",
              letterSpacing: "0.1em",
            },
          }}
        />
      </body>
    </html>
  );
}
