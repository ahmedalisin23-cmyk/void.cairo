"use client";
export const dynamic = "force-dynamic";
import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { SlidersHorizontal } from "lucide-react";
import { getProducts } from "@/lib/products";
import { ProductSkeletonGrid } from "@/components/ui/ProductSkeleton";
import ErrorState from "@/components/ui/ErrorState";
import type { Product } from "@/types";

const CATEGORIES = ["All", "Tees", "Hoodies", "Pants", "Accessories", "Outerwear"];

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [activeCategory, setActiveCategory] = useState("All");
  const [sortBy, setSortBy] = useState("newest");

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const data = await getProducts();
      setProducts(data);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  const filtered = products
    .filter((p) =>
      activeCategory === "All" ||
      p.category.toLowerCase() === activeCategory.toLowerCase()
    )
    .sort((a, b) => {
      if (sortBy === "price-asc") return a.price - b.price;
      if (sortBy === "price-desc") return b.price - a.price;
      if (sortBy === "newest") return new Date(b.createdAt as string).getTime() - new Date(a.createdAt as string).getTime();
      return 0;
    });

  return (
    <div className="min-h-screen pt-24 pb-16">
      {/* Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <p className="text-[10px] tracking-[0.5em] text-void-muted mb-2">COLLECTION</p>
          <h1 className="text-chrome" style={{ fontSize: "clamp(3rem,10vw,7rem)", fontFamily: "'Bebas Neue',sans-serif", letterSpacing: "0.15em" }}>
            ALL PRODUCTS
          </h1>
        </motion.div>
      </div>

      {/* Filters */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-10">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-1.5 text-[10px] tracking-[0.2em] uppercase transition-all duration-200 border ${
                  activeCategory === cat
                    ? "border-void-silver text-void-chrome bg-void-silver/10"
                    : "border-void-border text-void-muted hover:border-void-accent hover:text-void-chrome"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <SlidersHorizontal size={13} className="text-void-muted" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-transparent text-void-muted text-xs tracking-wider outline-none cursor-pointer"
            >
              <option value="newest" className="bg-black">NEWEST</option>
              <option value="price-asc" className="bg-black">PRICE: LOW → HIGH</option>
              <option value="price-desc" className="bg-black">PRICE: HIGH → LOW</option>
            </select>
          </div>
        </div>
        {!loading && !error && (
          <p className="text-xs text-void-muted tracking-wider mt-4">
            {filtered.length} PRODUCT{filtered.length !== 1 ? "S" : ""}
          </p>
        )}
      </div>

      {/* Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {loading && <ProductSkeletonGrid count={8} />}
        {error && <ErrorState message="FAILED TO LOAD PRODUCTS" onRetry={fetchProducts} />}
        {!loading && !error && filtered.length === 0 && (
          <div className="text-center py-24">
            <p className="text-xs tracking-[0.4em] text-void-muted">NO PRODUCTS IN THIS CATEGORY YET</p>
          </div>
        )}
        {!loading && !error && filtered.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {filtered.map((product, i) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Link href={`/products/${product.id}`} className="group block">
                  <div className="relative overflow-hidden bg-void-card border border-void-border aspect-[3/4] flex items-center justify-center transition-all duration-300 group-hover:border-void-accent">
                    {product.images?.[0] ? (
                      <Image
                        src={product.images[0]}
                        alt={product.name}
                        fill
                        className="object-cover transition-transform duration-700 group-hover:scale-105"
                        sizes="(max-width:640px) 50vw,(max-width:1024px) 33vw,25vw"
                      />
                    ) : (
                      <Image
                        src="/images/void-logo.png"
                        alt={product.name}
                        width={120}
                        height={48}
                        className="w-3/5 h-auto object-contain opacity-10 group-hover:opacity-20 transition-all duration-500 group-hover:scale-105"
                      />
                    )}

                    {/* Badges */}
                    <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
                      {product.newArrival && (
                        <span className="px-2 py-0.5 bg-void-silver text-black text-[9px] font-bold tracking-widest">NEW</span>
                      )}
                      {product.comparePrice && product.comparePrice > product.price && (
                        <span className="px-2 py-0.5 bg-red-900/80 text-red-300 text-[9px] font-bold tracking-widest">SALE</span>
                      )}
                    </div>

                    {/* Hover overlay */}
                    <div className="absolute inset-x-0 bottom-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300 bg-black/90 backdrop-blur-sm p-3 text-center z-10">
                      <span className="text-[11px] tracking-[0.2em] text-void-chrome">QUICK VIEW</span>
                    </div>
                  </div>

                  <div className="mt-3 px-0.5">
                    <h3 className="text-xs tracking-wider font-medium group-hover:text-void-chrome transition-colors line-clamp-2 leading-snug">
                      {product.name}
                    </h3>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="text-sm text-void-chrome font-medium">EGP {product.price.toLocaleString()}</span>
                      {product.comparePrice && product.comparePrice > product.price && (
                        <span className="text-xs text-void-muted line-through">EGP {product.comparePrice.toLocaleString()}</span>
                      )}
                    </div>
                    {product.variants?.length > 0 && (
                      <div className="flex gap-1.5 mt-2">
                        {product.variants.map((v) => (
                          <div
                            key={v.color}
                            className="w-2.5 h-2.5 rounded-full border border-void-border flex-shrink-0"
                            style={{ backgroundColor: v.colorHex }}
                            title={v.color}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
