import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Shop All — VOID Cairo",
  description: "Browse all VOID dark luxury streetwear drops. Limited quantities. Cairo made.",
};
export default function ProductsLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
