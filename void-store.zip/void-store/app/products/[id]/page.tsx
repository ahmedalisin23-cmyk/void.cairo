"use client";
export const dynamic = "force-dynamic";
import { useState, useEffect, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { ShoppingBag, Zap, Check, ArrowLeft, ChevronLeft, ChevronRight } from "lucide-react";
import { useCart } from "@/store/cart";
import { getProduct, getProducts } from "@/lib/products";
import ErrorState from "@/components/ui/ErrorState";
import toast from "react-hot-toast";
import { useParams } from "next/navigation";
import type { Product } from "@/types";

const SIZES = ["S", "M", "L", "XL", "XXL"] as const;

export default function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const { addItem, toggleCart } = useCart();

  const [product, setProduct] = useState<Product | null>(null);
  const [related, setRelated] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [activeImg, setActiveImg] = useState(0);
  const [selectedColor, setSelectedColor] = useState<Product["variants"][0] | null>(null);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [qty, setQty] = useState(1);

  const fetchProduct = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const [p, all] = await Promise.all([getProduct(id), getProducts()]);
      if (!p) { setError(true); return; }
      setProduct(p);
      setSelectedColor(p.variants?.[0] ?? null);
      setRelated(all.filter((x) => x.id !== id && x.category === p.category).slice(0, 4));
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => { fetchProduct(); }, [fetchProduct]);

  const handleAddToCart = () => {
    if (!product) return;
    if (!selectedColor) { toast.error("SELECT A COLOR"); return; }
    if (!selectedSize) { toast.error("SELECT A SIZE"); return; }
    addItem(product, selectedColor.color, selectedSize, qty);
    toast.success("ADDED TO CART");
  };

  const handleBuyNow = () => {
    if (!product) return;
    if (!selectedColor) { toast.error("SELECT A COLOR"); return; }
    if (!selectedSize) { toast.error("SELECT A SIZE"); return; }
    addItem(product, selectedColor.color, selectedSize, qty);
    toggleCart();
  };

  if (loading) {
    return (
      <div className="min-h-screen pt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 animate-pulse">
            <div className="space-y-3">
              <div className="aspect-square bg-void-card border border-void-border" />
              <div className="grid grid-cols-4 gap-2">
                {[0,1,2,3].map(i => <div key={i} className="aspect-square bg-void-card border border-void-border" />)}
              </div>
            </div>
            <div className="space-y-6 pt-4">
              <div className="h-4 bg-void-border rounded w-1/4" />
              <div className="h-8 bg-void-border rounded w-3/4" />
              <div className="h-6 bg-void-border rounded w-1/3" />
              <div className="h-px bg-void-border" />
              <div className="space-y-2">
                <div className="h-3 bg-void-border rounded w-full" />
                <div className="h-3 bg-void-border rounded w-5/6" />
                <div className="h-3 bg-void-border rounded w-4/6" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen pt-24 flex items-center justify-center">
        <ErrorState message="PRODUCT NOT FOUND" onRetry={fetchProduct} />
      </div>
    );
  }

  const sizeStock = selectedColor ? (selectedColor.sizes as Record<string, number>) : {};
  const images = product.images?.length > 0 ? product.images : [];
  const hasImages = images.length > 0;

  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Breadcrumb */}
        <Link href="/products" className="inline-flex items-center gap-1.5 text-[10px] tracking-[0.2em] text-void-muted hover:text-void-chrome transition-colors mb-8">
          <ArrowLeft size={12} /> ALL PRODUCTS
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          {/* ── Images ── */}
          <div className="space-y-3">
            {/* Main */}
            <div className="relative aspect-square bg-void-card border border-void-border overflow-hidden group flex items-center justify-center">
              {hasImages ? (
                <>
                  <Image
                    src={images[activeImg]}
                    alt={product.name}
                    fill
                    className="object-cover transition-opacity duration-300"
                    sizes="(max-width:1024px) 100vw, 50vw"
                    priority
                  />
                  {/* Prev/Next */}
                  {images.length > 1 && (
                    <>
                      <button
                        onClick={() => setActiveImg((activeImg - 1 + images.length) % images.length)}
                        className="absolute left-3 top-1/2 -translate-y-1/2 p-2 bg-black/60 text-void-chrome opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/80"
                      >
                        <ChevronLeft size={16} />
                      </button>
                      <button
                        onClick={() => setActiveImg((activeImg + 1) % images.length)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-black/60 text-void-chrome opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/80"
                      >
                        <ChevronRight size={16} />
                      </button>
                    </>
                  )}
                </>
              ) : (
                <div className="flex flex-col items-center gap-5">
                  <Image src="/images/void-logo.png" alt="VOID" width={220} height={88} className="w-2/3 h-auto object-contain opacity-12" />
                  <span className="text-[10px] tracking-[0.3em] text-void-muted">VISUAL COMING SOON</span>
                </div>
              )}
              {/* Badges */}
              <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
                {product.newArrival && <span className="px-2.5 py-1 bg-void-silver text-black text-[9px] font-bold tracking-widest">NEW ARRIVAL</span>}
                {product.comparePrice && product.comparePrice > product.price && (
                  <span className="px-2.5 py-1 bg-red-900/80 text-red-300 text-[9px] font-bold tracking-widest">SALE</span>
                )}
              </div>
            </div>

            {/* Thumbnails */}
            {hasImages && (
              <div className="grid grid-cols-4 gap-2">
                {images.slice(0, 4).map((url, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImg(i)}
                    className={`aspect-square border overflow-hidden transition-all duration-200 ${
                      activeImg === i ? "border-void-silver" : "border-void-border hover:border-void-accent"
                    }`}
                  >
                    <Image src={url} alt="" width={120} height={120} className="object-cover w-full h-full" />
                  </button>
                ))}
                {/* Empty placeholders */}
                {Array(Math.max(0, 4 - images.length)).fill(null).map((_, i) => (
                  <div key={`ph-${i}`} className="aspect-square bg-void-card border border-void-border/40 flex items-center justify-center">
                    <Image src="/images/void-logo.png" alt="" width={40} height={16} className="opacity-8 w-3/4 h-auto object-contain" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ── Info ── */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col space-y-6">
            {/* Name & Price */}
            <div>
              <p className="text-[10px] tracking-[0.4em] text-void-muted mb-2 uppercase">{product.category}</p>
              <h1 className="text-2xl sm:text-3xl font-medium tracking-wider leading-tight">{product.name}</h1>
              <div className="flex items-center gap-3 mt-4">
                <span className="text-2xl font-semibold text-void-chrome">EGP {product.price.toLocaleString()}</span>
                {product.comparePrice && product.comparePrice > product.price && (
                  <span className="text-base text-void-muted line-through">EGP {product.comparePrice.toLocaleString()}</span>
                )}
              </div>
            </div>

            <div className="h-px bg-void-border" />

            {/* Color */}
            {product.variants?.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] tracking-[0.25em] text-void-muted">COLOR</span>
                  <span className="text-[11px] tracking-wider text-void-chrome">{selectedColor?.color.toUpperCase()}</span>
                </div>
                <div className="flex gap-3">
                  {product.variants.map((v) => (
                    <button
                      key={v.color}
                      onClick={() => { setSelectedColor(v); setSelectedSize(null); }}
                      title={v.color}
                      className={`w-8 h-8 rounded-full border-2 transition-all duration-200 ${
                        selectedColor?.color === v.color
                          ? "border-void-silver scale-110 ring-2 ring-void-silver/20"
                          : "border-void-border hover:border-void-accent"
                      }`}
                      style={{ backgroundColor: v.colorHex }}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Size */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] tracking-[0.25em] text-void-muted">SIZE</span>
                <button className="text-[10px] tracking-wider text-void-muted underline underline-offset-4 hover:text-void-chrome transition-colors">
                  SIZE GUIDE
                </button>
              </div>
              <div className="grid grid-cols-5 gap-2">
                {SIZES.map((size) => {
                  const stock = sizeStock[size] ?? 0;
                  const out = stock === 0;
                  const low = stock > 0 && stock <= 3;
                  return (
                    <button
                      key={size}
                      onClick={() => !out && setSelectedSize(size)}
                      disabled={out}
                      className={`relative py-3 text-xs tracking-wider border transition-all duration-200 ${
                        selectedSize === size
                          ? "border-void-silver text-void-chrome bg-void-silver/10"
                          : out
                          ? "border-void-border/20 text-void-border/40 cursor-not-allowed line-through"
                          : "border-void-border text-void-muted hover:border-void-accent hover:text-void-chrome"
                      }`}
                    >
                      {size}
                      {low && !out && (
                        <span className="absolute -top-1 -right-1 w-2 h-2 bg-amber-500 rounded-full" />
                      )}
                    </button>
                  );
                })}
              </div>
              {selectedSize && sizeStock[selectedSize] > 0 && sizeStock[selectedSize] <= 3 && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-[10px] text-amber-400 tracking-wider mt-2"
                >
                  ONLY {sizeStock[selectedSize]} LEFT IN THIS SIZE
                </motion.p>
              )}
            </div>

            {/* Quantity */}
            <div>
              <span className="text-[10px] tracking-[0.25em] text-void-muted block mb-3">QUANTITY</span>
              <div className="flex items-center border border-void-border w-fit">
                <button onClick={() => setQty(Math.max(1, qty - 1))} className="px-4 py-2.5 text-void-muted hover:text-void-chrome hover:bg-void-border/30 transition-all">−</button>
                <span className="px-6 text-sm font-medium w-12 text-center">{qty}</span>
                <button onClick={() => setQty(qty + 1)} className="px-4 py-2.5 text-void-muted hover:text-void-chrome hover:bg-void-border/30 transition-all">+</button>
              </div>
            </div>

            {/* CTAs */}
            <div className="flex flex-col gap-3 pt-2">
              <button onClick={handleBuyNow} className="btn-chrome w-full py-4 text-sm tracking-[0.25em] font-bold uppercase flex items-center justify-center gap-2">
                <Zap size={15} /> BUY NOW
              </button>
              <button onClick={handleAddToCart} className="btn-primary w-full py-4 text-sm tracking-[0.2em] uppercase flex items-center justify-center gap-2">
                <ShoppingBag size={15} /> ADD TO CART
              </button>
            </div>

            <div className="h-px bg-void-border" />

            {/* Description */}
            {product.description && (
              <div>
                <p className="text-[10px] tracking-[0.25em] text-void-muted mb-3">ABOUT THIS PIECE</p>
                <p className="text-sm text-void-muted leading-relaxed">{product.description}</p>
              </div>
            )}

            {/* Details */}
            <div className="space-y-2">
              {["Heavy 300gsm cotton", "Oversized silhouette", "3D foam logo print", "Pre-washed & pre-shrunk", "Machine wash cold — inside out"].map((d) => (
                <div key={d} className="flex items-start gap-2.5">
                  <Check size={11} className="text-void-silver mt-0.5 flex-shrink-0" />
                  <span className="text-xs text-void-muted">{d}</span>
                </div>
              ))}
            </div>

            {/* Tags */}
            {product.tags?.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-1">
                {product.tags.map((tag) => (
                  <span key={tag} className="px-2.5 py-1 border border-void-border text-[10px] tracking-wider text-void-muted">
                    {tag.toUpperCase()}
                  </span>
                ))}
              </div>
            )}
          </motion.div>
        </div>

        {/* Related Products */}
        {related.length > 0 && (
          <section className="mt-24">
            <div className="flex items-end justify-between mb-8">
              <div>
                <p className="text-[10px] tracking-[0.4em] text-void-muted mb-1">MORE FROM VOID</p>
                <h2 className="text-3xl text-chrome" style={{ fontFamily: "'Bebas Neue',sans-serif", letterSpacing: "0.15em" }}>YOU MAY ALSO LIKE</h2>
              </div>
              <Link href="/products" className="text-[10px] tracking-[0.2em] text-void-muted hover:text-void-chrome transition-colors">
                VIEW ALL →
              </Link>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {related.map((rp, i) => (
                <motion.div
                  key={rp.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08 }}
                >
                  <Link href={`/products/${rp.id}`} className="group block">
                    <div className="aspect-[3/4] bg-void-card border border-void-border flex items-center justify-center overflow-hidden group-hover:border-void-accent transition-colors relative">
                      {rp.images?.[0] ? (
                        <Image src={rp.images[0]} alt={rp.name} fill className="object-cover group-hover:scale-105 transition-transform duration-700" />
                      ) : (
                        <Image src="/images/void-logo.png" alt="" width={80} height={32} className="w-1/2 h-auto opacity-10 group-hover:opacity-20 transition-opacity" />
                      )}
                    </div>
                    <p className="mt-2 text-xs tracking-wider group-hover:text-void-chrome transition-colors line-clamp-1">{rp.name}</p>
                    <p className="text-sm text-void-chrome mt-0.5">EGP {rp.price.toLocaleString()}</p>
                  </Link>
                </motion.div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
