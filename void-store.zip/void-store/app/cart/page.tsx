"use client";
import { useCart } from "@/store/cart";
import Link from "next/link";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from "lucide-react";

export default function CartPage() {
  const { items, removeItem, updateQuantity, total, clearCart } = useCart();

  if (items.length === 0) {
    return (
      <div className="min-h-screen pt-24 flex flex-col items-center justify-center px-4 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="w-20 h-20 border border-void-border flex items-center justify-center mx-auto mb-6">
            <ShoppingBag size={28} className="text-void-muted" />
          </div>
          <p className="text-[10px] tracking-[0.5em] text-void-muted mb-2">EMPTY</p>
          <h1
            className="text-chrome mb-8"
            style={{ fontSize: "clamp(3rem, 10vw, 6rem)", fontFamily: "'Bebas Neue', sans-serif", letterSpacing: "0.15em" }}
          >
            YOUR CART IS VOID
          </h1>
          <Link href="/products">
            <button className="btn-chrome px-10 py-4 text-xs tracking-[0.3em] font-bold flex items-center gap-2 mx-auto">
              SHOP NOW <ArrowRight size={14} />
            </button>
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-[10px] tracking-[0.5em] text-void-muted mb-1">REVIEW</p>
            <h1
              className="text-chrome"
              style={{ fontSize: "clamp(2.5rem, 8vw, 5rem)", fontFamily: "'Bebas Neue', sans-serif", letterSpacing: "0.15em" }}
            >
              YOUR CART
            </h1>
          </div>
          <button
            onClick={clearCart}
            className="text-xs tracking-[0.2em] text-void-muted hover:text-red-400 transition-colors"
          >
            CLEAR ALL
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Items */}
          <div className="lg:col-span-2 space-y-4">
            <AnimatePresence>
              {items.map((item, idx) => (
                <motion.div
                  key={`${item.product.id}-${item.color}-${item.size}`}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20, height: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="card-void p-5 flex gap-5"
                >
                  {/* Image */}
                  <div className="w-24 h-28 sm:w-28 sm:h-32 bg-void-border/20 border border-void-border flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {item.product.images?.[0] ? (
                      <Image src={item.product.images[0]} alt={item.product.name} width={112} height={128} className="object-cover w-full h-full" />
                    ) : (
                      <Image src="/images/void-logo.png" alt="" width={60} height={24} className="w-3/4 h-auto object-contain opacity-15" />
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 flex flex-col justify-between min-w-0">
                    <div>
                      <h3 className="text-sm font-medium tracking-wider leading-snug">{item.product.name}</h3>
                      <p className="text-xs text-void-muted mt-1 tracking-wider">
                        {item.color.toUpperCase()} · SIZE {item.size}
                      </p>
                    </div>

                    <div className="flex items-center justify-between mt-3">
                      {/* Qty */}
                      <div className="flex items-center border border-void-border">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.color, item.size, item.quantity - 1)}
                          className="p-2 text-void-muted hover:text-void-chrome hover:bg-void-border/30 transition-all"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="px-4 text-sm font-medium w-10 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.color, item.size, item.quantity + 1)}
                          className="p-2 text-void-muted hover:text-void-chrome hover:bg-void-border/30 transition-all"
                        >
                          <Plus size={12} />
                        </button>
                      </div>

                      <div className="flex items-center gap-4">
                        <span className="text-base font-medium text-void-chrome">
                          EGP {(item.product.price * item.quantity).toLocaleString()}
                        </span>
                        <button
                          onClick={() => removeItem(item.product.id, item.color, item.size)}
                          className="p-1.5 text-void-muted hover:text-red-400 transition-colors"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            <Link href="/products" className="inline-flex items-center gap-2 text-xs tracking-[0.2em] text-void-muted hover:text-void-chrome transition-colors mt-2">
              ← CONTINUE SHOPPING
            </Link>
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="card-void p-6 sticky top-24 space-y-5">
              <h2 className="text-xs tracking-[0.3em] text-void-chrome">ORDER SUMMARY</h2>

              <div className="space-y-3 text-sm">
                <div className="flex justify-between text-void-muted">
                  <span>Subtotal ({items.reduce((s, i) => s + i.quantity, 0)} items)</span>
                  <span>EGP {total().toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-void-muted">
                  <span>Shipping</span>
                  <span className={total() >= 1500 ? "text-green-400" : ""}>
                    {total() >= 1500 ? "FREE" : "EGP 60"}
                  </span>
                </div>
                {total() < 1500 && (
                  <p className="text-[10px] tracking-wider text-void-muted border border-void-border/50 px-3 py-2">
                    ADD EGP {(1500 - total()).toLocaleString()} MORE FOR FREE SHIPPING
                  </p>
                )}
              </div>

              <div className="border-t border-void-border pt-4 flex justify-between items-center">
                <span className="text-sm font-medium">Total</span>
                <span className="text-xl font-semibold text-void-chrome">
                  EGP {(total() + (total() >= 1500 ? 0 : 60)).toLocaleString()}
                </span>
              </div>

              <Link href="/checkout">
                <button className="btn-chrome w-full py-4 text-xs tracking-[0.3em] font-bold flex items-center justify-center gap-2">
                  CHECKOUT <ArrowRight size={14} />
                </button>
              </Link>

              {/* Trust badges */}
              <div className="pt-2 space-y-2">
                {["CASH ON DELIVERY", "SECURE CHECKOUT", "EASY RETURNS"].map((badge) => (
                  <div key={badge} className="flex items-center gap-2">
                    <div className="w-1 h-1 bg-void-silver rounded-full" />
                    <span className="text-[10px] tracking-[0.2em] text-void-muted">{badge}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
