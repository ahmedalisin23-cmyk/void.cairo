import { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "VOID Cairo",
    short_name: "VOID",
    description: "Dark luxury streetwear from Cairo",
    start_url: "/",
    display: "standalone",
    background_color: "#000000",
    theme_color: "#000000",
    icons: [
      { src: "/images/void-logo.png", sizes: "192x192", type: "image/png" },
      { src: "/images/void-logo.png", sizes: "512x512", type: "image/png" },
    ],
  };
}
