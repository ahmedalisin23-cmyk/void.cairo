"use client";
export const dynamic = "force-dynamic";
import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { useCart } from "@/store/cart";
import { addOrder } from "@/lib/orders";
import { syncOrderToSheets } from "@/lib/sheets";
import toast from "react-hot-toast";
import { useRouter } from "next/navigation";
import { CheckCircle2, ArrowLeft } from "lucide-react";

export default function CheckoutPage() {
  const { items, total, clearCart } = useCart();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [orderId, setOrderId] = useState("");
  const [form, setForm] = useState({
    name: "", phone: "", email: "", address: "", city: "", notes: "",
  });

  const shipping = total() >= 1500 ? 0 : 60;
  const grandTotal = total() + shipping;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone || !form.address || !form.city) {
      toast.error("PLEASE FILL ALL REQUIRED FIELDS");
      return;
    }
    if (items.length === 0) {
      toast.error("YOUR CART IS EMPTY");
      return;
    }
    setLoading(true);
    try {
      const id = await addOrder({
        customerName: form.name,
        customerPhone: form.phone,
        customerEmail: form.email,
        customerAddress: `${form.address}, ${form.city}`,
        items,
        totalAmount: grandTotal,
        status: "pending",
        notes: form.notes,
      });

      // Sync to Google Sheets in background
      syncOrderToSheets({
        id,
        customerName: form.name,
        customerPhone: form.phone,
        customerEmail: form.email,
        customerAddress: `${form.address}, ${form.city}`,
        items,
        totalAmount: grandTotal,
        status: "pending",
        notes: form.notes,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });

      setOrderId(id);
      clearCart();
      setSuccess(true);
    } catch {
      toast.error("ORDER FAILED — TRY AGAIN");
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center max-w-md"
        >
          <div className="w-16 h-16 border border-void-silver/30 flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 size={32} className="text-void-silver" />
          </div>
          <p className="text-[10px] tracking-[0.5em] text-void-muted mb-3">ORDER CONFIRMED</p>
          <h1 className="text-5xl text-chrome mb-6" style={{ fontFamily: "'Bebas Neue', sans-serif", letterSpacing: "0.15em" }}>
            ORDER PLACED
          </h1>
          <p className="text-void-muted text-sm leading-relaxed mb-2">
            Your order has been received. We&apos;ll confirm via WhatsApp on
          </p>
          <p className="text-void-chrome text-sm font-medium mb-8">{form.phone}</p>
          <div className="border border-void-border p-4 mb-8 text-left space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-void-muted tracking-wider">ORDER ID</span>
              <span className="text-void-chrome font-mono text-[11px]">{orderId.slice(0, 8).toUpperCase()}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-void-muted tracking-wider">TOTAL</span>
              <span className="text-void-chrome">EGP {grandTotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-void-muted tracking-wider">PAYMENT</span>
              <span className="text-void-chrome">CASH ON DELIVERY</span>
            </div>
          </div>
          <a
            href={`https://wa.me/+20${form.phone.replace(/[^0-9]/g, "").replace(/^20/, "").replace(/^0/, "")}`}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-chrome w-full py-4 text-xs tracking-[0.3em] font-bold flex items-center justify-center gap-2 mb-3"
          >
            📱 TRACK ON WHATSAPP
          </a>
          <button onClick={() => router.push("/")} className="btn-primary w-full py-4 text-xs tracking-[0.3em] uppercase">
            CONTINUE SHOPPING
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link href="/cart" className="flex items-center gap-2 text-void-muted hover:text-void-chrome text-xs tracking-wider mb-8 transition-colors">
          <ArrowLeft size={14} /> BACK TO CART
        </Link>

        <div className="mb-10">
          <p className="text-[10px] tracking-[0.5em] text-void-muted mb-1">SECURE CHECKOUT</p>
          <h1 className="text-5xl text-chrome" style={{ fontFamily: "'Bebas Neue', sans-serif", letterSpacing: "0.15em" }}>
            CHECKOUT
          </h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
          {/* Form */}
          <form onSubmit={handleSubmit} className="lg:col-span-3 space-y-5">
            <div className="card-void p-6 space-y-5">
              <h2 className="text-xs tracking-[0.3em] text-void-chrome">CUSTOMER INFORMATION</h2>
              {[
                { key: "name", label: "FULL NAME *", type: "text", placeholder: "Ahmed Ali" },
                { key: "phone", label: "PHONE / WHATSAPP *", type: "tel", placeholder: "+20 1XX XXX XXXX" },
                { key: "email", label: "EMAIL (OPTIONAL)", type: "email", placeholder: "ahmed@example.com" },
              ].map(({ key, label, type, placeholder }) => (
                <div key={key}>
                  <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">{label}</label>
                  <input
                    type={type}
                    value={form[key as keyof typeof form]}
                    onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                    placeholder={placeholder}
                    className="w-full bg-transparent border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none transition-colors placeholder:text-void-border/60"
                  />
                </div>
              ))}
            </div>

            <div className="card-void p-6 space-y-5">
              <h2 className="text-xs tracking-[0.3em] text-void-chrome">DELIVERY ADDRESS</h2>
              <div>
                <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">STREET ADDRESS *</label>
                <textarea
                  required
                  rows={2}
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  placeholder="Street, Building No., Floor, Apartment"
                  className="w-full bg-transparent border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none transition-colors resize-none placeholder:text-void-border/60"
                />
              </div>
              <div>
                <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">CITY / AREA *</label>
                <select
                  value={form.city}
                  onChange={(e) => setForm({ ...form, city: e.target.value })}
                  className="w-full bg-void-card border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none"
                >
                  <option value="" className="bg-black">SELECT AREA</option>
                  {["New Cairo", "Nasr City", "Maadi", "Zamalek", "Heliopolis", "October City", "Sheikh Zayed", "Downtown Cairo", "Other"].map(c => (
                    <option key={c} value={c} className="bg-black">{c}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[10px] tracking-[0.2em] text-void-muted mb-2">ORDER NOTES (OPTIONAL)</label>
                <textarea
                  rows={2}
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder="Special instructions, landmark, etc."
                  className="w-full bg-transparent border border-void-border px-4 py-3 text-sm text-void-chrome focus:border-void-silver focus:outline-none transition-colors resize-none placeholder:text-void-border/60"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading || items.length === 0}
              className="btn-chrome w-full py-4 text-sm tracking-[0.25em] font-bold uppercase disabled:opacity-40"
            >
              {loading ? "PLACING ORDER..." : `PLACE ORDER — EGP ${grandTotal.toLocaleString()}`}
            </button>
            <p className="text-[10px] text-void-muted text-center tracking-[0.2em]">
              CASH ON DELIVERY · CONFIRMED VIA WHATSAPP
            </p>
          </form>

          {/* Summary */}
          <div className="lg:col-span-2">
            <div className="card-void p-6 sticky top-24">
              <h2 className="text-xs tracking-[0.3em] text-void-chrome mb-5">ORDER SUMMARY</h2>
              <div className="space-y-4 mb-5">
                {items.map((item, i) => (
                  <div key={i} className="flex gap-3">
                    <div className="w-14 h-18 bg-void-border/20 border border-void-border flex items-center justify-center flex-shrink-0" style={{ height: "4.5rem" }}>
                      {item.product.images?.[0] ? (
                        <Image src={item.product.images[0]} alt="" width={56} height={72} className="object-cover w-full h-full" />
                      ) : (
                        <Image src="/images/void-logo.png" alt="" width={36} height={14} className="opacity-15 w-4/5 h-auto object-contain" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs tracking-wider font-medium line-clamp-2 leading-snug">{item.product.name}</p>
                      <p className="text-[10px] text-void-muted mt-0.5">{item.color} · {item.size} · ×{item.quantity}</p>
                      <p className="text-sm font-medium mt-1">EGP {(item.product.price * item.quantity).toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t border-void-border pt-4 space-y-2.5">
                <div className="flex justify-between text-sm text-void-muted">
                  <span>Subtotal</span>
                  <span>EGP {total().toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm text-void-muted">
                  <span>Shipping</span>
                  <span className={shipping === 0 ? "text-green-400" : ""}>{shipping === 0 ? "FREE" : `EGP ${shipping}`}</span>
                </div>
                <div className="flex justify-between text-base font-semibold pt-2 border-t border-void-border">
                  <span>Total</span>
                  <span className="text-void-chrome">EGP {grandTotal.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
