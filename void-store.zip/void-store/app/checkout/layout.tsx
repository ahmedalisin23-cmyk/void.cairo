import type { Metadata } from "next";
export const metadata: Metadata = { title: "Checkout — VOID Cairo" };
export default function CheckoutLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
