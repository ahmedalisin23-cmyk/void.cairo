import { db } from "./firebase";
import {
  collection, doc, getDocs, addDoc, updateDoc,
  query, orderBy, serverTimestamp,
} from "firebase/firestore";
import { Order } from "@/types";

const COL = "orders";

export async function getOrders(): Promise<Order[]> {
  const snap = await getDocs(query(collection(db, COL), orderBy("createdAt", "desc")));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Order));
}

export async function addOrder(data: Omit<Order, "id" | "createdAt" | "updatedAt">): Promise<string> {
  const ref = await addDoc(collection(db, COL), { ...data, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
  return ref.id;
}

export async function updateOrderStatus(id: string, status: Order["status"]): Promise<void> {
  await updateDoc(doc(db, COL, id), { status, updatedAt: serverTimestamp() });
}
