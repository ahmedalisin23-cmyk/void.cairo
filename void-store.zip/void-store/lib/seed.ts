/**
 * VOID Cairo — Firestore Seed Script
 * Run once to populate your database with demo products.
 *
 * Usage (after setting up Firebase):
 *   npx ts-node --project tsconfig.json lib/seed.ts
 *
 * Or run from browser console in /admin/dashboard by calling seedProducts()
 */
import { addProduct } from "./products";

const DEMO_PRODUCTS = [
  {
    name: "VOID OVERSIZED TEE — ONYX",
    description: "300gsm heavyweight cotton. Oversized silhouette. Dark grey 3D foam VOID logo on left chest. Pre-washed. Built to last, designed to disturb.",
    price: 899,
    comparePrice: undefined,
    category: "tees",
    featured: true,
    newArrival: true,
    tags: ["oversized", "tee", "black", "heavyweight", "premium"],
    images: [],
    variants: [
      { color: "Onyx Black", colorHex: "#000000", sizes: { S: 8, M: 12, L: 15, XL: 10, XXL: 5 } },
      { color: "Washed Black", colorHex: "#111111", sizes: { S: 5, M: 8, L: 10, XL: 6, XXL: 3 } },
      { color: "Charcoal", colorHex: "#2a2a2a", sizes: { S: 3, M: 6, L: 8, XL: 5, XXL: 2 } },
    ],
  },
  {
    name: "VOID HEAVY TEE — GREY VOID",
    description: "Same heavyweight formula. Grey canvas for the 3D foam logo to breathe. Drop silhouette. Unisex fit.",
    price: 899,
    comparePrice: 1099,
    category: "tees",
    featured: true,
    newArrival: false,
    tags: ["oversized", "tee", "grey", "heavyweight"],
    images: [],
    variants: [
      { color: "Ash Grey", colorHex: "#888888", sizes: { S: 6, M: 10, L: 12, XL: 8, XXL: 4 } },
      { color: "Dark Grey", colorHex: "#444444", sizes: { S: 4, M: 7, L: 9, XL: 5, XXL: 2 } },
    ],
  },
  {
    name: "VOID HOODIE — ONYX",
    description: "500gsm fleece. Double-layered hood. Kangaroo pocket. VOID chest logo embossed in matte 3D rubber. The winter essential.",
    price: 1499,
    comparePrice: undefined,
    category: "hoodies",
    featured: true,
    newArrival: true,
    tags: ["hoodie", "black", "fleece", "winter", "premium"],
    images: [],
    variants: [
      { color: "Onyx Black", colorHex: "#000000", sizes: { S: 5, M: 8, L: 10, XL: 7, XXL: 3 } },
      { color: "Washed Black", colorHex: "#1a1a1a", sizes: { S: 3, M: 5, L: 7, XL: 4, XXL: 2 } },
    ],
  },
  {
    name: "VOID HOODIE — ASH",
    description: "Same 500gsm formula in Ash Grey. Cold weather uniform. Oversized but structured.",
    price: 1499,
    comparePrice: undefined,
    category: "hoodies",
    featured: false,
    newArrival: false,
    tags: ["hoodie", "grey", "fleece", "winter"],
    images: [],
    variants: [
      { color: "Ash Grey", colorHex: "#888888", sizes: { S: 4, M: 7, L: 9, XL: 6, XXL: 3 } },
    ],
  },
  {
    name: "VOID LOGO CAP — CHROME",
    description: "6-panel structured cap. Chrome VOID embroidery front. Adjustable buckle strap. One size fits most.",
    price: 499,
    comparePrice: undefined,
    category: "accessories",
    featured: false,
    newArrival: false,
    tags: ["cap", "hat", "chrome", "accessories"],
    images: [],
    variants: [
      { color: "Black/Chrome", colorHex: "#000000", sizes: { S: 20, M: 20, L: 20, XL: 20, XXL: 20 } },
    ],
  },
  {
    name: "VOID CARGO PANTS — ONYX",
    description: "Heavyweight twill cargo pants. 8 pockets. VOID tab on left cargo pocket. Relaxed tapered fit.",
    price: 1899,
    comparePrice: undefined,
    category: "pants",
    featured: false,
    newArrival: true,
    tags: ["cargo", "pants", "black", "premium", "limited"],
    images: [],
    variants: [
      { color: "Onyx Black", colorHex: "#000000", sizes: { S: 5, M: 8, L: 8, XL: 5, XXL: 2 } },
      { color: "Washed Black", colorHex: "#222222", sizes: { S: 3, M: 5, L: 5, XL: 3, XXL: 1 } },
    ],
  },
  {
    name: "VOID LONG SLEEVE — BLACK VOID",
    description: "Midweight 220gsm long sleeve. Clean base. VOID logo on left chest, subtle back print. Layering essential.",
    price: 999,
    comparePrice: undefined,
    category: "tees",
    featured: false,
    newArrival: false,
    tags: ["longsleeve", "tee", "black", "layering"],
    images: [],
    variants: [
      { color: "Black", colorHex: "#000000", sizes: { S: 8, M: 12, L: 14, XL: 9, XXL: 4 } },
      { color: "Faded Black", colorHex: "#1c1c1c", sizes: { S: 4, M: 6, L: 8, XL: 5, XXL: 2 } },
    ],
  },
  {
    name: "VOID BEANIE — ONYX",
    description: "100% merino wool. Ribbed construction. Subtle VOID patch on fold. Unisex.",
    price: 349,
    comparePrice: undefined,
    category: "accessories",
    featured: false,
    newArrival: false,
    tags: ["beanie", "hat", "wool", "winter", "accessories"],
    images: [],
    variants: [
      { color: "Onyx Black", colorHex: "#000000", sizes: { S: 20, M: 20, L: 20, XL: 20, XXL: 20 } },
      { color: "Dark Grey", colorHex: "#555555", sizes: { S: 15, M: 15, L: 15, XL: 15, XXL: 15 } },
    ],
  },
];

export async function seedProducts() {
  console.log("🌑 VOID: Seeding products to Firestore...");
  for (const product of DEMO_PRODUCTS) {
    try {
      const id = await addProduct(product);
      console.log(`✓ Added: ${product.name} (${id})`);
    } catch (err) {
      console.error(`✗ Failed: ${product.name}`, err);
    }
  }
  console.log("🌑 VOID: Seed complete.");
}
