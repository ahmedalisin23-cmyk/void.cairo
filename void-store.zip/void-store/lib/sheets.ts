/**
 * VOID Cairo — Google Sheets Sync
 * 
 * Setup:
 * 1. Go to Google Sheets → Extensions → Apps Script
 * 2. Deploy as Web App (Anyone can access)
 * 3. Paste the Apps Script code below in Apps Script editor
 * 4. Set NEXT_PUBLIC_SHEETS_WEBHOOK_URL in .env.local to the web app URL
 * 
 * ===== Apps Script Code (paste in Google Apps Script) =====
 * 
 * function doPost(e) {
 *   var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
 *   var data = JSON.parse(e.postData.contents);
 *   
 *   // Add header if sheet is empty
 *   if (sheet.getLastRow() === 0) {
 *     sheet.appendRow([
 *       "Order ID", "Date", "Name", "Phone", "Email",
 *       "Address", "Items", "Total (EGP)", "Status"
 *     ]);
 *     sheet.getRange(1, 1, 1, 9).setFontWeight("bold");
 *   }
 *   
 *   sheet.appendRow([
 *     data.id,
 *     data.date,
 *     data.customerName,
 *     data.customerPhone,
 *     data.customerEmail || "",
 *     data.customerAddress,
 *     data.items,
 *     data.total,
 *     data.status
 *   ]);
 *   
 *   return ContentService
 *     .createTextOutput(JSON.stringify({ success: true }))
 *     .setMimeType(ContentService.MimeType.JSON);
 * }
 * ===== End Apps Script =====
 */

import type { Order } from "@/types";

const SHEETS_WEBHOOK = process.env.NEXT_PUBLIC_SHEETS_WEBHOOK_URL;

export async function syncOrderToSheets(order: Order): Promise<boolean> {
  if (!SHEETS_WEBHOOK) {
    console.warn("VOID: Google Sheets webhook URL not configured");
    return false;
  }

  try {
    const payload = {
      id: order.id,
      date: new Date(order.createdAt as string).toLocaleString("en-EG"),
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      customerEmail: order.customerEmail || "",
      customerAddress: order.customerAddress,
      items: order.items
        .map((i) => `${i.product.name} (${i.color} / ${i.size} × ${i.quantity})`)
        .join(" | "),
      total: order.totalAmount,
      status: order.status.toUpperCase(),
    };

    const res = await fetch(SHEETS_WEBHOOK, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    return res.ok;
  } catch (err) {
    console.error("VOID: Failed to sync order to Google Sheets", err);
    return false;
  }
}
