import { ref as storageRef, uploadBytes, getDownloadURL, deleteObject } from "firebase/storage";
import { storage } from "@/lib/firebase";

export async function uploadProductImage(file: File, productId?: string): Promise<string> {
  const folder = productId ? `products/${productId}` : "products/temp";
  const filename = `${Date.now()}-${file.name.replace(/[^a-z0-9.]/gi, "_").toLowerCase()}`;
  const path = `${folder}/${filename}`;
  const ref = storageRef(storage, path);
  const snap = await uploadBytes(ref, file, { contentType: file.type });
  return getDownloadURL(snap.ref);
}

export async function uploadMultipleImages(files: File[], productId?: string): Promise<string[]> {
  return Promise.all(Array.from(files).map((f) => uploadProductImage(f, productId)));
}

export async function deleteImageByUrl(url: string): Promise<void> {
  try {
    // Extract path from Firebase Storage URL
    const match = url.match(/\/o\/(.+?)\?/);
    if (!match) return;
    const path = decodeURIComponent(match[1]);
    const ref = storageRef(storage, path);
    await deleteObject(ref);
  } catch {
    console.warn("Could not delete image:", url);
  }
}
