/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "firebasestorage.googleapis.com" },
      { protocol: "https", hostname: "storage.googleapis.com" },
      { protocol: "https", hostname: "*.cloudflare.com" },
    ],
  },
  // Cloudflare Pages compatibility
  output: "standalone",
};

export default nextConfig;
