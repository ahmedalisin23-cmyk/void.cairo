import { create } from "zustand";
import { persist } from "zustand/middleware";
import { CartItem, Product } from "@/types";

interface CartStore {
  items: CartItem[];
  isOpen: boolean;
  addItem: (product: Product, color: string, size: string, quantity: number) => void;
  removeItem: (productId: string, color: string, size: string) => void;
  updateQuantity: (productId: string, color: string, size: string, quantity: number) => void;
  clearCart: () => void;
  toggleCart: () => void;
  total: () => number;
  count: () => number;
}

export const useCart = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      isOpen: false,
      addItem: (product, color, size, quantity) => {
        const items = get().items;
        const existing = items.find(
          (i) => i.product.id === product.id && i.color === color && i.size === size
        );
        if (existing) {
          set({ items: items.map((i) =>
            i.product.id === product.id && i.color === color && i.size === size
              ? { ...i, quantity: i.quantity + quantity }
              : i
          )});
        } else {
          set({ items: [...items, { product, color, size, quantity }] });
        }
      },
      removeItem: (productId, color, size) => {
        set({ items: get().items.filter(
          (i) => !(i.product.id === productId && i.color === color && i.size === size)
        )});
      },
      updateQuantity: (productId, color, size, quantity) => {
        if (quantity <= 0) {
          get().removeItem(productId, color, size);
          return;
        }
        set({ items: get().items.map((i) =>
          i.product.id === productId && i.color === color && i.size === size
            ? { ...i, quantity }
            : i
        )});
      },
      clearCart: () => set({ items: [] }),
      toggleCart: () => set((s) => ({ isOpen: !s.isOpen })),
      total: () => get().items.reduce((sum, i) => sum + i.product.price * i.quantity, 0),
      count: () => get().items.reduce((sum, i) => sum + i.quantity, 0),
    }),
    { name: "void-cart" }
  )
);
