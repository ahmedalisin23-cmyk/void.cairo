import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        void: {
          black:  "#000000",
          dark:   "#080808",
          card:   "#0d0d0d",
          border: "#1a1a1a",
          silver: "#c0c0c0",
          chrome: "#e8e8e8",
          muted:  "#666666",
          accent: "#8a8a8a",
        },
      },
      fontFamily: {
        display: ["'Bebas Neue'", "sans-serif"],
        sans:    ["'Inter'", "sans-serif"],
      },
      animation: {
        "float":   "float 5s ease-in-out infinite",
        "marquee": "marquee 22s linear infinite",
        "shimmer": "shimmer 2.5s linear infinite",
        "pulse-slow": "pulse 3s ease-in-out infinite",
      },
      keyframes: {
        float: {
          "0%,100%": { transform: "translateY(0px)" },
          "50%":     { transform: "translateY(-14px)" },
        },
        marquee: {
          "0%":   { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        shimmer: {
          "0%":   { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
